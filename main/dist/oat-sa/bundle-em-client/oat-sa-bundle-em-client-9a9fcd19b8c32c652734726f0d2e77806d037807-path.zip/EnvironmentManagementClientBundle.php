<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

namespace OAT\Bundle\EnvironmentManagementClientBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EnvironmentManagementClientBundle extends Bundle
{

}
