<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Http;

use OAT\Library\EnvironmentManagementClient\Http\AuthorizationDetailsMarkerInterface;
use Symfony\Bridge\PsrHttpMessage\HttpFoundationFactoryInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Response;

final class ResponseHelper
{
    private HttpMessageFactoryInterface $httpMessageFactory;
    private HttpFoundationFactoryInterface $httpFoundationFactory;
    private AuthorizationDetailsMarkerInterface $authorizationDetailsHeaderMarker;

    public function __construct(
        HttpMessageFactoryInterface $httpMessageFactory,
        HttpFoundationFactoryInterface $httpFoundationFactory,
        AuthorizationDetailsMarkerInterface $authorizationDetailsHeaderMarker
    ) {
        $this->httpMessageFactory = $httpMessageFactory;
        $this->httpFoundationFactory = $httpFoundationFactory;
        $this->authorizationDetailsHeaderMarker = $authorizationDetailsHeaderMarker;
    }

    public function withAuthorizationDetailsMarker(
        Response $response,
        string $clientId,
        string $refreshTokenId,
        ?string $userIdentifier = null,
        ?string $userRole = null,
        ?string $cookieDomain = null,
        ?string $ltiToken = null,
        ?string $mode = AuthorizationDetailsMarkerInterface::MODE_COOKIE,
        ?string $storagePrefix = null,
    ): Response {
        $psrResponse = $this->authorizationDetailsHeaderMarker->withAuthDetails(
            $this->httpMessageFactory->createResponse($response),
            $clientId,
            $refreshTokenId,
            $userIdentifier,
            $userRole,
            $cookieDomain,
            $ltiToken,
            $mode,
            $storagePrefix,
        );

        return $this->httpFoundationFactory->createResponse($psrResponse);
    }
}
