<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver;

use OAT\Library\EnvironmentManagementClient\Exception\LtiMessageExtractFailedException;
use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Http\LtiMessageExtractorInterface;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayloadInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class LtiMessagePayloadValueResolver implements ArgumentValueResolverInterface
{
    private HttpMessageFactoryInterface $httpMessageFactory;
    private LtiMessageExtractorInterface $ltiMessageExtractor;

    public function __construct(
        HttpMessageFactoryInterface $httpMessageFactory,
        LtiMessageExtractorInterface $ltiMessageExtractor
    ) {
        $this->httpMessageFactory = $httpMessageFactory;
        $this->ltiMessageExtractor = $ltiMessageExtractor;
    }

    public function supports(Request $request, ArgumentMetadata $argument): bool
    {
        return $argument->getType() === LtiMessagePayloadInterface::class;
    }

    public function resolve(Request $request, ArgumentMetadata $argument): iterable
    {
        if (!$this->supports($request, $argument)) {
            return [];
        }

        $psrRequest = $this->httpMessageFactory->createRequest($request);

        try {
            yield $this->ltiMessageExtractor->extract($psrRequest);
        } catch (LtiMessageExtractFailedException $exception) {
            throw new BadRequestHttpException($exception->getMessage(), $exception);
        } catch (TokenUnauthorizedException $exception) {
            throw new UnauthorizedHttpException('Bearer', $exception->getMessage(), $exception);
        }
    }
}
