<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver;

use OAT\Library\EnvironmentManagementClient\Exception\TenantIdNotFoundException;
use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Http\TenantIdExtractorInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

final class TenantIdValueResolver implements ArgumentValueResolverInterface
{
    private HttpMessageFactoryInterface $psrHttpFactory;
    private TenantIdExtractorInterface $tenantIdExtractor;

    public function __construct(
        HttpMessageFactoryInterface $psrHttpFactory,
        TenantIdExtractorInterface $tenantIdExtractor
    ) {
        $this->psrHttpFactory = $psrHttpFactory;
        $this->tenantIdExtractor = $tenantIdExtractor;
    }

    public function supports(Request $request, ArgumentMetadata $argument): bool
    {
        return $argument->getType() === 'string' && $argument->getName() === 'tenantId';
    }

    /**
     * @throws TenantIdNotFoundException
     */
    public function resolve(Request $request, ArgumentMetadata $argument): iterable
    {
        if (!$this->supports($request, $argument)) {
            return [];
        }

        $psrRequest = $this->psrHttpFactory->createRequest($request);

        try {
            yield $this->tenantIdExtractor->extract($psrRequest);
        } catch (TokenUnauthorizedException $exception) {
            throw new UnauthorizedHttpException('Bearer', $exception->getMessage(), $exception);
        }
    }
}
