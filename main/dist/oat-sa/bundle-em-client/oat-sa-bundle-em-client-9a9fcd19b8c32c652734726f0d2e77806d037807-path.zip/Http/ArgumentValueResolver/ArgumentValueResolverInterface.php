<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver;

use RuntimeException;
use Symfony\Component\HttpKernel\Controller\ValueResolverInterface;
use Symfony\Component\HttpKernel\Controller\ArgumentValueResolverInterface as DeprecatedArgumentValueResolverInterface;

if (interface_exists(ValueResolverInterface::class)) {
    interface ArgumentValueResolverInterface extends ValueResolverInterface
    {
    }
} elseif (interface_exists(DeprecatedArgumentValueResolverInterface::class)) {
    interface ArgumentValueResolverInterface extends DeprecatedArgumentValueResolverInterface
    {
    }
} else {
    throw new RuntimeException('You need to add "symfony/http-kernel" as a Composer dependency.');
}
