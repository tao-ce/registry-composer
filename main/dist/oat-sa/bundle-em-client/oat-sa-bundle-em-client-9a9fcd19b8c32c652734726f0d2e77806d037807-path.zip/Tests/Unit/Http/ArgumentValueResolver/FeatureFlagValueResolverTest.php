<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Tests\Unit\Http\ArgumentValueResolver;

use Generator;
use OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver\FeatureFlagValueResolver;
use OAT\Library\EnvironmentManagementClient\Http\FeatureFlagExtractorInterface;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlagCollection;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;

final class FeatureFlagValueResolverTest extends TestCase
{
    private MockObject|HttpMessageFactoryInterface $messageFactoryMock;
    private FeatureFlagExtractorInterface|MockObject $flagExtractorMock;
    private FeatureFlagValueResolver $subject;

    protected function setUp(): void
    {
        $this->messageFactoryMock = $this->createMock(HttpMessageFactoryInterface::class);
        $this->flagExtractorMock = $this->createMock(FeatureFlagExtractorInterface::class);

        $this->subject = new FeatureFlagValueResolver($this->messageFactoryMock, $this->flagExtractorMock);
    }

    public function testSupports(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);

        $metadataMock->expects($this->once())
            ->method('getType')
            ->willReturn(FeatureFlagCollection::class);

        $this->assertTrue($this->subject->supports(new Request(), $metadataMock));
    }

    public function testResolve(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);
        $request = new Request();
        $psrRequest = $this->createMock(ServerRequestInterface::class);

        $this->messageFactoryMock->expects($this->once())
            ->method('createRequest')
            ->with($request)
            ->willReturn($psrRequest);

        $this->flagExtractorMock->expects($this->once())
            ->method('extract')
            ->with($psrRequest)
            ->willReturn(new FeatureFlagCollection());

        $generator = $this->subject->resolve($request, $metadataMock);
        $this->assertInstanceOf(Generator::class, $generator);
        $generator->rewind();
    }
}
