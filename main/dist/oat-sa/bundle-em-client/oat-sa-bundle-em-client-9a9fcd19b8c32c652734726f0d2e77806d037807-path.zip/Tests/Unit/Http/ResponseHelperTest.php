<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Tests\Unit\Http;

use OAT\Bundle\EnvironmentManagementClientBundle\Http\ResponseHelper;
use OAT\Library\EnvironmentManagementClient\Http\AuthorizationDetailsMarkerInterface;
use PHPUnit\Framework\TestCase;
use Psr\Http\Message\ResponseInterface;
use Symfony\Bridge\PsrHttpMessage\HttpFoundationFactoryInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Response;

final class ResponseHelperTest extends TestCase
{
    public function testWithAuthorizationDetailsMarker(): void
    {
        $messageFactoryMock = $this->createMock(HttpMessageFactoryInterface::class);
        $foundationFactoryMock = $this->createMock(HttpFoundationFactoryInterface::class);
        $authMarkerFactoryMock = $this->createMock(AuthorizationDetailsMarkerInterface::class);

        $response = new Response();
        $response->headers->set('X-OAT-WITH-AUTH-DETAILS', json_encode([
            'clientId' => 'clientId',
            'refreshTokenId' => 'refreshTokenId',
            'userIdentifier' => null,
            'userRole' => null,
            'mode' => AuthorizationDetailsMarkerInterface::MODE_COOKIE,
            'cookieDomain' => 'tao.com',
            'ltiToken' => 'jwt-token',
            'storagePrefix' => 'prefix.'
        ]));
        $psrResponse = $this->createMock(ResponseInterface::class);

        $messageFactoryMock->expects($this->once())
            ->method('createResponse')
            ->with($response)
            ->willReturn($psrResponse);

        $authMarkerFactoryMock->expects($this->once())
            ->method('withAuthDetails')
            ->with($psrResponse, "clientId", "refreshTokenId", null, null, "tao.com", "jwt-token", AuthorizationDetailsMarkerInterface::MODE_COOKIE, "prefix.")
            ->willReturn($psrResponse);

        $foundationFactoryMock->expects($this->once())
            ->method('createResponse')
            ->with($psrResponse)
            ->willReturn($response);

        $subject = new ResponseHelper($messageFactoryMock, $foundationFactoryMock, $authMarkerFactoryMock);

        $response = $subject->withAuthorizationDetailsMarker($response, "clientId", "refreshTokenId", null, null, "tao.com", "jwt-token",  "cookie", "prefix.");
        $withAuthDetailsHeader = $response->headers->get('X-OAT-WITH-AUTH-DETAILS');

        $this->assertNotNull(
            $withAuthDetailsHeader,
            "withAuthDetails is null"
        );

        $res_array = (array)json_decode($withAuthDetailsHeader);

        $this->assertArrayHasKey('clientId', $res_array);
        $this->assertEquals('clientId', $res_array['clientId']);
        $this->assertArrayHasKey('refreshTokenId', $res_array);
        $this->assertEquals('refreshTokenId', $res_array['refreshTokenId']);
        $this->assertEquals('tao.com', $res_array['cookieDomain']);
        $this->assertEquals('jwt-token', $res_array['ltiToken']);
        $this->assertArrayHasKey('mode', $res_array);
        $this->assertEquals('prefix.', $res_array['storagePrefix']);
        $this->assertEquals(AuthorizationDetailsMarkerInterface::MODE_COOKIE, $res_array['mode']);
    }
}
