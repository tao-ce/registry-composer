<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Tests\Unit\Http\ArgumentValueResolver;

use Generator;
use OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver\TenantIdValueResolver;
use OAT\Library\EnvironmentManagementClient\Exception\TenantIdNotFoundException;
use OAT\Library\EnvironmentManagementClient\Http\TenantIdExtractorInterface;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlagCollection;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;

final class TenantIdValueResolverTest extends TestCase
{
    private MockObject|HttpMessageFactoryInterface $messageFactoryMock;
    private TenantIdExtractorInterface|MockObject $tenantIdExtractorMock;
    private TenantIdValueResolver $subject;

    protected function setUp(): void
    {
        $this->messageFactoryMock = $this->createMock(HttpMessageFactoryInterface::class);
        $this->tenantIdExtractorMock = $this->createMock(TenantIdExtractorInterface::class);

        $this->subject = new TenantIdValueResolver($this->messageFactoryMock, $this->tenantIdExtractorMock);
    }

    public function testSupports(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);

        $metadataMock->expects($this->once())
            ->method('getType')
            ->willReturn('string');

        $metadataMock->expects($this->once())
            ->method('getName')
            ->willReturn('tenantId');

        $this->assertTrue($this->subject->supports(new Request(), $metadataMock));
    }

    public function testResolveForSuccess(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);
        $request = new Request();
        $psrRequest = $this->createMock(ServerRequestInterface::class);

        $this->messageFactoryMock->expects($this->once())
            ->method('createRequest')
            ->with($request)
            ->willReturn($psrRequest);

        $this->tenantIdExtractorMock->expects($this->once())
            ->method('extract')
            ->with($psrRequest)
            ->willReturn('tenant-1');

        $generator = $this->subject->resolve($request, $metadataMock);
        $this->assertInstanceOf(Generator::class, $generator);
        $this->assertEquals('tenant-1', $generator->current());
    }
}
