<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\Tests\Unit\Http\ArgumentValueResolver;

use Generator;
use OAT\Bundle\EnvironmentManagementClientBundle\Http\ArgumentValueResolver\LtiMessagePayloadValueResolver;
use OAT\Library\EnvironmentManagementClient\Exception\LtiMessageExtractFailedException;
use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Http\LtiMessageExtractorInterface;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayload;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayloadInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Psr\Http\Message\ServerRequestInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadata;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class LtiMessagePayloadValueResolverTest extends TestCase
{
    private MockObject|HttpMessageFactoryInterface $messageFactoryMock;
    private MockObject|LtiMessageExtractorInterface $ltiMessageExtractorMock;
    private LtiMessagePayloadValueResolver $subject;

    protected function setUp(): void
    {
        $this->messageFactoryMock = $this->createMock(HttpMessageFactoryInterface::class);
        $this->ltiMessageExtractorMock = $this->createMock(LtiMessageExtractorInterface::class);

        $this->subject = new LtiMessagePayloadValueResolver(
            $this->messageFactoryMock,
            $this->ltiMessageExtractorMock,
        );
    }

    public function testSupports(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);

        $metadataMock->expects($this->once())
            ->method('getType')
            ->willReturn(LtiMessagePayloadInterface::class);

        $this->assertTrue($this->subject->supports(new Request(), $metadataMock));
    }

    public function testResolve(): void
    {
        $metadataMock = $this->createMock(ArgumentMetadata::class);
        $psrRequest = $this->createMock(ServerRequestInterface::class);
        $ltiMessagePayloadMock = $this->createMock(LtiMessagePayload::class);
        $request = new Request();

        $this->messageFactoryMock->expects($this->once())
            ->method('createRequest')
            ->with($request)
            ->willReturn($psrRequest);

        $this->ltiMessageExtractorMock->expects($this->once())
            ->method('extract')
            ->with($psrRequest)
            ->willReturn($ltiMessagePayloadMock);

        $generator = $this->subject->resolve($request, $metadataMock);
        $this->assertInstanceOf(Generator::class, $generator);
        $this->assertEquals($ltiMessagePayloadMock, $generator->current());
    }

    public function testExtractLtiMessageWillThrowBadRequestExceptionWhenRequestIsEmpty(): void
    {
        $this->messageFactoryMock
            ->method('createRequest')
            ->willReturn($this->createMock(ServerRequestInterface::class));
        $internalException = LtiMessageExtractFailedException::unableToExtractLtiMessage();
        $this->ltiMessageExtractorMock
            ->method('extract')
            ->willThrowException($internalException);

        $this->expectExceptionObject(new BadRequestHttpException($internalException->getMessage(), $internalException));

        iterator_to_array(
            $this->subject->resolve(
                new Request(),
                $this->createMock(ArgumentMetadata::class)
            )
        );
    }

    public function testExtractLtiMessageWillThrowUnauthorizedExceptionWhenAccessTokenIsInvalid(): void
    {
        $this->messageFactoryMock
            ->method('createRequest')
            ->willReturn($this->createMock(ServerRequestInterface::class));
        $internalException = new TokenUnauthorizedException();
        $this->ltiMessageExtractorMock
            ->method('extract')
            ->willThrowException($internalException);

        $this->expectExceptionObject(
            new UnauthorizedHttpException('Bearer', $internalException->getMessage(), $internalException)
        );

        iterator_to_array(
            $this->subject->resolve(
                new Request(),
                $this->createMock(ArgumentMetadata::class)
            )
        );
    }
}
