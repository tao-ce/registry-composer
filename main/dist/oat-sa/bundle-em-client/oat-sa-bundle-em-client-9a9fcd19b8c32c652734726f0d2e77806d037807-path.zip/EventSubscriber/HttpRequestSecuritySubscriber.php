<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Bundle\EnvironmentManagementClientBundle\EventSubscriber;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Http\JWTTokenExtractorInterface;
use Symfony\Bridge\PsrHttpMessage\HttpMessageFactoryInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\HttpKernel\KernelEvents;

class HttpRequestSecuritySubscriber implements EventSubscriberInterface
{
    public function __construct(
        private JWTTokenExtractorInterface $jwtTokenExtractor,
        private HttpMessageFactoryInterface $httpMessageFactory,
    ) {}

    public static function getSubscribedEvents(): array
    {
        return [
            KernelEvents::REQUEST => [
                ['validateRouteOauth2Scopes', 10],
            ],
        ];
    }

    public function validateRouteOauth2Scopes(RequestEvent $event): void
    {
        if (!$event->isMainRequest()) {
            return;
        }

        $request = $event->getRequest();
        $allowedScopes = $request->attributes->get('em_oauth2_scopes');

        if (!$allowedScopes) {
            return;
        }

        $psrRequest = $this->httpMessageFactory->createRequest($request);

        try {
            $token = $this->jwtTokenExtractor->extract($psrRequest);
        } catch (TokenUnauthorizedException $exception) {
            throw new UnauthorizedHttpException('Bearer', $exception->getMessage(), $exception);
        }

        $scopes = $token->claims()->get('scopes');

        if (!is_array($scopes)) {
            $scopes = explode(' ', $scopes);
        }

        if (count(array_intersect($scopes, $allowedScopes)) === 0) {
            throw new UnauthorizedHttpException('Bearer', 'Invalid scope(s)');
        }
    }
}
