<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiEvents\Tests\Unit\Factory;

use DateTimeImmutable;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\CreateLineItemEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\DeleteLineItemEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\GetLineItemEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\ListLineItemsEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\ListResultsEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\PublishScoreEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Ags\UpdateLineItemEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\BasicOutcome\DeleteResultEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\BasicOutcome\ReadResultEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\BasicOutcome\ReplaceResultEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\BasicOutcome\SendBasicOutcomeEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Core\RequestEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\EventInterface;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Nrps\GetContextMembershipEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Nrps\GetResourceLinkMembershipEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Event\Proctoring\SendControlEvent;
use OAT\Library\EnvironmentManagementLtiEvents\Factory\LtiSerializerFactory;
use OAT\Library\Lti1p3Ags\Model\LineItem\LineItem;
use OAT\Library\Lti1p3Ags\Model\Score\Score;
use OAT\Library\Lti1p3Core\Resource\LtiResourceLink\LtiResourceLink;
use OAT\Library\Lti1p3Proctoring\Model\AcsControl;
use OAT\Library\Lti1p3Proctoring\Model\AcsControlInterface;
use PHPUnit\Framework\TestCase;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\SerializerInterface;

class LtiSerializerTest extends TestCase
{
    private SerializerInterface $sut;

    /**
     * @before
     */
    public function init(): void
    {
        $this->sut = LtiSerializerFactory::create();
    }

    /**
     * @dataProvider dataProvider
     */
    public function testEventSerialization(EventInterface $event): void
    {
        $this->assertEquals(
            $event,
            $this->sut->deserialize(
                $this->sut->serialize($event, JsonEncoder::FORMAT),
                EventInterface::class,
                JsonEncoder::FORMAT
            )
        );
    }

    public function dataProvider(): array
    {
        return [
            [new CreateLineItemEvent('test', new LineItem(1, 'test'), 'https://example.com')],
            [new DeleteLineItemEvent('test', 'https://example.com')],
            [new GetLineItemEvent('test', 'https://example.com')],
            [new ListLineItemsEvent('test', 'https://example.com')],
            [new ListResultsEvent('test', 'https://example.com')],
            [new PublishScoreEvent('test', new Score('test'), 'https://example.com')],
            [new UpdateLineItemEvent('test', new LineItem(1, 'test'))],
            [new DeleteResultEvent('test', 'https://example.com', 'test')],
            [new ReadResultEvent('test', 'https://example.com', 'test')],
            [new ReplaceResultEvent('test', 'https://example.com', 'test', 1)],
            [new SendBasicOutcomeEvent('test', 'https://example.com', '<xml/>')],
            [new RequestEvent('test', 'GET', 'https://example.com')],
            [new GetContextMembershipEvent('test', 'https://example.com')],
            [new GetResourceLinkMembershipEvent('test', 'https://example.com', 'test')],
            [
                new SendControlEvent(
                    'test',
                    new AcsControl(
                        new LtiResourceLink('https://example.com'),
                        'test',
                        AcsControlInterface::ACTION_PAUSE,
                        DateTimeImmutable::createFromFormat('U.u', sprintf('%.3f', microtime(true)))
                    ),
                    'https://example.com'
                ),
            ],
        ];
    }
}
