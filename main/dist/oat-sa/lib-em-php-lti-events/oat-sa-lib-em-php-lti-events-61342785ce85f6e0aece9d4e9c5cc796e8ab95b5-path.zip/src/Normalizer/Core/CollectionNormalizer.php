<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Core;

use OAT\Library\Lti1p3Core\Util\Collection\Collection;
use OAT\Library\Lti1p3Core\Util\Collection\CollectionInterface;
use Symfony\Component\Serializer\Exception\InvalidArgumentException;
use Symfony\Component\Serializer\Normalizer\DenormalizerInterface;
use Symfony\Component\Serializer\Normalizer\NormalizerInterface;

class CollectionNormalizer implements NormalizerInterface, DenormalizerInterface
{
    private const PARAM_ITEMS = 'items';

    /**
     * @param CollectionInterface $object
     */
    public function normalize(mixed $object, ?string $format = null, array $context = []): array
    {
        return [
            self::PARAM_ITEMS => $object->all(),
        ];
    }

    public function getSupportedTypes(?string $format): array 
    {
        return [
            CollectionInterface::class => true
        ];
    }

    public function supportsNormalization(mixed $data, ?string $format = null, array $context = []): bool
    {
        return $data instanceof CollectionInterface;
    }

    public function denormalize(mixed $data, string $type, ?string $format = null, array $context = []): Collection
    {
        if (!is_array($data)) {
            throw new InvalidArgumentException(sprintf('Data expected to be an array, "%s" given.', get_debug_type($data)));
        }

        $collection = new Collection();

        $collection->add($data[self::PARAM_ITEMS] ?? []);

        return $collection;
    }

    public function supportsDenormalization(mixed $data, string $type, ?string $format = null, array $context = []): bool
    {
        return is_a($type, CollectionInterface::class, true);
    }
}
