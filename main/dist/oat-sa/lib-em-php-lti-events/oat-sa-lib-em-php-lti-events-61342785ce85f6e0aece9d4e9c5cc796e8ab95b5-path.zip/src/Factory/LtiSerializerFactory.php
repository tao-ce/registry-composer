<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiEvents\Factory;

use DateTimeInterface;
use Error;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Ags\LineItemNormalizer;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Ags\ScoreNormalizer;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Ags\SubmissionReviewNormalizer;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Core\CollectionNormalizer;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Core\ResourceLinkNormalizer;
use OAT\Library\EnvironmentManagementLtiEvents\Normalizer\Proctoring\AcsControlNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Mapping\ClassDiscriminatorFromClassMetadata;
use Symfony\Component\Serializer\Mapping\Factory\ClassMetadataFactory;
use Symfony\Component\Serializer\Mapping\Loader\AnnotationLoader;
use Symfony\Component\Serializer\Mapping\Loader\AttributeLoader;
use Symfony\Component\Serializer\Normalizer\DateTimeNormalizer;
use Symfony\Component\Serializer\Normalizer\JsonSerializableNormalizer;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;
use Symfony\Component\Serializer\SerializerInterface;

class LtiSerializerFactory
{
    public static function create(): SerializerInterface
    {
        try {
            $loader = new AttributeLoader();
        } catch (Error) {
            $loader = new AnnotationLoader();
        }
        $classMetaDataFactory = new ClassMetadataFactory($loader);
        $classDiscriminator = new ClassDiscriminatorFromClassMetadata($classMetaDataFactory);

        return new Serializer(
            [
                new LineItemNormalizer(),
                new SubmissionReviewNormalizer(),
                new CollectionNormalizer(),
                new ScoreNormalizer(),
                new AcsControlNormalizer(),
                new ResourceLinkNormalizer(),
                new JsonSerializableNormalizer(),
                new DateTimeNormalizer([DateTimeNormalizer::FORMAT_KEY => DateTimeInterface::RFC3339_EXTENDED]),
                new ObjectNormalizer($classMetaDataFactory, null, null, null, $classDiscriminator),
            ],
            [
                new JsonEncoder(),
            ],
        );
    }
}
