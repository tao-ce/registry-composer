<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiEvents\Event\Proctoring;

use OAT\Library\EnvironmentManagementLtiEvents\Event\EventInterface;
use OAT\Library\Lti1p3Proctoring\Model\AcsControlInterface;

class SendControlEvent implements EventInterface
{
    public const TYPE = 'proctoringSendControl';

    public function __construct(
        private string $registrationId,
        private AcsControlInterface $control,
        private string $acsUrl
    ) {}

    public function getRegistrationId(): string
    {
        return $this->registrationId;
    }

    public function getControl(): AcsControlInterface
    {
        return $this->control;
    }

    public function getAcsUrl(): string
    {
        return $this->acsUrl;
    }
}
