<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Tests\Unit\Gateway;

use GuzzleHttp\ClientInterface;
use InvalidArgumentException;
use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiGatewayException;
use OAT\Library\EnvironmentManagementLtiClient\Gateway\LtiGateway;
use OAT\Library\EnvironmentManagementLtiEvents\Event\EventInterface;
use PHPUnit\Framework\TestCase;
use RuntimeException;
use Symfony\Component\Serializer\SerializerInterface;

final class LtiGatewayTest extends TestCase
{
    public function testEmptyUrlProvided(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Lti Gateway Url cannot be empty.');

        new LtiGateway('');
    }

    public function testSendForSuccess(): void
    {
        $clientMock = $this->createMock(ClientInterface::class);
        $serializerMock = $this->createMock(SerializerInterface::class);
        $eventMock = $this->createMock(EventInterface::class);
        $url = 'http://local.mock';

        $serializerMock->expects($this->once())
            ->method('serialize')
            ->with($eventMock, 'json')
            ->willReturn('json-serialized-body');

        $clientMock->expects($this->once())
            ->method('request')
            ->with(
                'POST',
                sprintf('%s/api/v1/lti/events', $url),
                [
                    'headers' => [
                        'Content-Type' => 'application/json',
                    ],
                    'body' => 'json-serialized-body'
                ]
            );

        $gateway = new LtiGateway($url, $clientMock, $serializerMock);
        $gateway->send($eventMock);
    }

    public function testSendForFailure(): void
    {
        $clientMock = $this->createMock(ClientInterface::class);

        $clientMock->expects($this->once())
            ->method('request')
            ->willThrowException(new RuntimeException('something wrong'));

        $this->expectException(LtiGatewayException::class);
        $this->expectExceptionMessage('Cannot perform request: something wrong');

        $gateway = new LtiGateway('http://local.mock', $clientMock);
        $gateway->send($this->createMock(EventInterface::class));
    }
}
