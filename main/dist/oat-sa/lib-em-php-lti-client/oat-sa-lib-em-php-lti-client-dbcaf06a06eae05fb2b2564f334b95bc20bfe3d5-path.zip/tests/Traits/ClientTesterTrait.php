<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Tests\Traits;

use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\StreamInterface;

trait ClientTesterTrait
{
    protected function getResponseMock(int $statusCode, int $statusCodeInvokedCount = 1, string $rawBody = ''): ResponseInterface
    {
        $responseMock = $this->createMock(ResponseInterface::class);

        $responseMock->expects($this->exactly($statusCodeInvokedCount))
            ->method('getStatusCode')
            ->willReturn($statusCode);

        if ($rawBody) {
            $streamMock = $this->createMock(StreamInterface::class);
            $streamMock->expects($this->once())
                ->method('getContents')
                ->willReturn($rawBody);

            $responseMock->expects($this->once())
                ->method('getBody')
                ->willReturn($streamMock);
        }

        return $responseMock;
    }
}
