<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Gateway;

use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiGatewayException;
use OAT\Library\EnvironmentManagementLtiEvents\Event\EventInterface;
use Psr\Http\Message\ResponseInterface;

interface LtiGatewayInterface
{
    /**
     * @throws LtiGatewayException
     */
    public function send(EventInterface $event): ResponseInterface;
}
