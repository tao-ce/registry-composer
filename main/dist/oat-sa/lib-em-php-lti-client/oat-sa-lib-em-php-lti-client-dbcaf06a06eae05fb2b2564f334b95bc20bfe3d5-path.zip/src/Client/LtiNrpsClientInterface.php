<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Client;

use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiNrpsClientException;
use OAT\Library\Lti1p3Nrps\Model\Membership\MembershipInterface;

interface LtiNrpsClientInterface
{
    /**
     * @throws LtiNrpsClientException
     */
    public function getContextMembership(
        string $registrationId,
        string $membershipServiceUrl,
        ?string $role = null,
        ?int $limit = null
    ): MembershipInterface;

    /**
     * @throws LtiNrpsClientException
     */
    public function getResourceLinkMembershipForPayload(
        string $registrationId,
        string $membershipServiceUrl,
        string $resourceLinkIdentifier,
        ?string $role = null,
        ?int $limit = null
    ): MembershipInterface;
}
