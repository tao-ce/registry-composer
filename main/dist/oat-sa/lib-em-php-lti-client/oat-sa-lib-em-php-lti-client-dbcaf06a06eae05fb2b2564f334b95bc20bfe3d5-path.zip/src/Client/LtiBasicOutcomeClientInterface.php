<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Client;

use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiBasicOutcomeClientException;
use OAT\Library\Lti1p3BasicOutcome\Message\Response\BasicOutcomeResponseInterface;

interface LtiBasicOutcomeClientInterface
{
    /**
     * @throws LtiBasicOutcomeClientException
     */
    public function deleteResult(string $registrationId, string $lisOutcomeServiceUrl, string $lisResultSourcedId): void;

    /**
     * @throws LtiBasicOutcomeClientException
     */
    public function readResult(
        string $registrationId,
        string $lisOutcomeServiceUrl,
        string $lisResultSourcedId,
    ): BasicOutcomeResponseInterface;

    /**
     * @throws LtiBasicOutcomeClientException
     */
    public function replaceResult(
        string $registrationId,
        string $lisOutcomeServiceUrl,
        string $lisResultSourcedId,
        float $score,
        string $language = 'en',
    ): void;

    /**
     * @throws LtiBasicOutcomeClientException
     */
    public function sendBasicOutcome(
        string $registrationId,
        string $lisOutcomeServiceUrl,
        string $xml,
    ): void;
}
