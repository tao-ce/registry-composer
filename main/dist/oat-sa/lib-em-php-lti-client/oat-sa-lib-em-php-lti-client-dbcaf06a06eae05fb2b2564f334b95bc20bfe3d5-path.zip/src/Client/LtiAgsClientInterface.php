<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Client;

use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiAgsClientException;
use OAT\Library\Lti1p3Ags\Model\LineItem\LineItemContainerInterface;
use OAT\Library\Lti1p3Ags\Model\LineItem\LineItemInterface;
use OAT\Library\Lti1p3Ags\Model\Result\ResultContainerInterface;
use OAT\Library\Lti1p3Ags\Model\Score\ScoreInterface;
use OAT\Library\Lti1p3Core\Exception\LtiException;

interface LtiAgsClientInterface
{
    /**
     * @throws LtiAgsClientException
     */
    public function createLineItem(
        string $registrationId,
        LineItemInterface $lineItem,
        string $lineItemsContainerUrl,
    ): void;

    /**
     * @throws LtiAgsClientException
     */
    public function deleteLineItem(string $registrationId, string $lineItemUrl): void;

    /**
     * @throws LtiAgsClientException
     */
    public function getLineItem(
        string $registrationId,
        string $lineItemUrl,
        array $scopes = [],
    ): LineItemInterface;

    /**
     * @throws LtiAgsClientException
     * @throws LtiException
     */
    public function listLineItems(
        string $registrationId,
        string $lineItemsContainerUrl,
        ?string $resourceIdentifier = null,
        ?string $resourceLinkIdentifier = null,
        ?string $tag = null,
        ?int $limit = null,
        ?int $offset = null,
        ?array $scopes = null
    ): LineItemContainerInterface;

    /**
     * @throws LtiAgsClientException
     * @throws LtiException
     */
    public function listResults(
        string $registrationId,
        string $lineItemUrl,
        ?string $userIdentifier = null,
        ?int $limit = null,
        ?int $offset = null
    ): ResultContainerInterface;

    /**
     * @throws LtiAgsClientException
     */
    public function publishScore(
        string $registrationId,
        ScoreInterface $score,
        string $lineItemUrl
    ): void;

    /**
     * @throws LtiAgsClientException
     */
    public function updateLineItem(
        string $registrationId,
        LineItemInterface $lineItem,
        ?string $lineItemUrl = null
    ): void;
}
