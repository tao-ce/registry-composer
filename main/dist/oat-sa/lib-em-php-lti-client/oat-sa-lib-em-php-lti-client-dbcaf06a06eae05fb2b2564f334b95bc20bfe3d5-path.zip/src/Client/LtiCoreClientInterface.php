<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementLtiClient\Client;

use OAT\Library\EnvironmentManagementLtiClient\Exception\LtiCoreClientException;
use Psr\Http\Message\ResponseInterface;

interface LtiCoreClientInterface
{
    /**
     * @throws LtiCoreClientException
     */
    public function request(
        string $registrationId,
        string $method,
        string $uri,
        array $options = [],
        array $scopes = []
    ): ResponseInterface;
}
