<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Converter;

use OAT\Library\EnvironmentManagementClient\Model\LtiToolInterface;
use OAT\Library\Lti1p3Core\Tool\Tool;
use OAT\Library\Lti1p3Core\Tool\ToolInterface;

class LtiToolConverter
{
    public function convert(LtiToolInterface $tool): ToolInterface
    {
        return new Tool(
            $tool->getId(),
            $tool->getName(),
            $tool->getAudience(),
            $tool->getOidcInitiationUrl(),
            $tool->getLaunchUrl(),
            $tool->getDeepLinkingUrl()
        );
    }
}
