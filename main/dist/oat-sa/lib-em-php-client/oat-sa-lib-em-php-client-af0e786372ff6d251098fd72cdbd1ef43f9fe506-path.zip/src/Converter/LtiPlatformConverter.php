<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Converter;

use OAT\Library\EnvironmentManagementClient\Model\LtiPlatformInterface;
use OAT\Library\Lti1p3Core\Platform\Platform;
use OAT\Library\Lti1p3Core\Platform\PlatformInterface;

class LtiPlatformConverter
{
    public function convert(LtiPlatformInterface $platform): PlatformInterface
    {
        return new Platform(
            $platform->getId(),
            $platform->getName(),
            $platform->getAudience(),
            $platform->getOidcAuthenticationUrl(),
            $platform->getOauth2AccessTokenUrl()
        );
    }
}
