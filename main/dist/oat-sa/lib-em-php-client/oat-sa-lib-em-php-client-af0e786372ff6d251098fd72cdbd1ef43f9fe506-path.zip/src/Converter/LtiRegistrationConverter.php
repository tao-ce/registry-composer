<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Converter;

use InvalidArgumentException;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationInterface;
use OAT\Library\EnvironmentManagementClient\Model\TenantAwareRegistration;
use OAT\Library\EnvironmentManagementClient\Model\TenantAwareRegistrationInterface;
use OAT\Library\Lti1p3Core\Registration\Registration;
use OAT\Library\Lti1p3Core\Registration\RegistrationInterface;
use OAT\Library\Lti1p3Core\Security\Key\KeyChainFactoryInterface;

class LtiRegistrationConverter
{
    private LtiPlatformConverter $platformConverter;
    private LtiToolConverter $toolConverter;
    private KeyChainFactoryInterface $keyChainFactory;

    public function __construct(
        LtiPlatformConverter $platformConverter,
        LtiToolConverter $toolConverter,
        KeyChainFactoryInterface $keyChainFactory,
    ) {
        $this->platformConverter = $platformConverter;
        $this->toolConverter = $toolConverter;
        $this->keyChainFactory = $keyChainFactory;
    }

    public function convert(LtiRegistrationInterface $ltiRegistration): RegistrationInterface
    {
        if (null === $ltiRegistration->getLtiPlatform()) {
            throw new InvalidArgumentException(sprintf(
                'LTI Platform not returned for Registration %s',
                $ltiRegistration->getId(),
            ));
        }

        if (null === $ltiRegistration->getLtiTool()) {
            throw new InvalidArgumentException(sprintf(
                'LTI Tool not returned for Registration %s',
                $ltiRegistration->getId(),
            ));
        }

        $ltiPlatformKeyChain = $ltiRegistration->getPlatformKeyChain();
        $ltiToolKeyChain = $ltiRegistration->getToolKeyChain();

        return new Registration(
            $ltiRegistration->getId(),
            $ltiRegistration->getClientId(),
            $this->platformConverter->convert($ltiRegistration->getLtiPlatform()),
            $this->toolConverter->convert($ltiRegistration->getLtiTool()),
            $ltiRegistration->getDeploymentIds(),
            $ltiPlatformKeyChain
            && $ltiPlatformKeyChain->getPublicKey()
            && $ltiPlatformKeyChain->getPrivateKey()
            && $ltiPlatformKeyChain->getKeySetName()
                ? $this->keyChainFactory->create(
                $ltiPlatformKeyChain?->getId(),
                $ltiPlatformKeyChain?->getKeySetName(),
                $ltiPlatformKeyChain?->getPublicKey(),
                $ltiPlatformKeyChain?->getPrivateKey(),
                $ltiPlatformKeyChain?->getPrivateKeyPassphrase(),
            )
                : null,
            $ltiToolKeyChain
            && $ltiToolKeyChain->getPublicKey()
            && $ltiToolKeyChain->getPrivateKey()
            && $ltiToolKeyChain->getKeySetName()
                ? $this->keyChainFactory->create(
                $ltiToolKeyChain->getId(),
                $ltiToolKeyChain->getKeySetName(),
                $ltiToolKeyChain->getPublicKey(),
                $ltiToolKeyChain->getPrivateKey(),
                $ltiToolKeyChain->getPrivateKeyPassphrase(),
            )
                : null,
            $ltiRegistration->getPlatformJwksUrl(),
            $ltiRegistration->getToolJwksUrl(),
        );
    }

    public function convertWithTenantId(LtiRegistrationInterface $ltiRegistration): TenantAwareRegistrationInterface
    {
        return TenantAwareRegistration::fromBaseRegistration(
            $this->convert($ltiRegistration),
            $ltiRegistration->getTenantId(),
        );
    }
}
