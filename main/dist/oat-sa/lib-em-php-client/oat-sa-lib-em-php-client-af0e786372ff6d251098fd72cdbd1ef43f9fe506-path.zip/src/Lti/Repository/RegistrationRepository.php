<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Lti\Repository;

use BadMethodCallException;
use OAT\Library\EnvironmentManagementClient\Converter\LtiRegistrationConverter;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Repository\LtiRegistrationRepositoryInterface;
use OAT\Library\Lti1p3Core\Registration\RegistrationInterface;
use OAT\Library\Lti1p3Core\Registration\RegistrationRepositoryInterface;

readonly class RegistrationRepository implements RegistrationRepositoryInterface
{
    public function __construct(
        private LtiRegistrationRepositoryInterface $ltiRegistrationRepository,
        private LtiRegistrationConverter $ltiRegistrationConverter,
    ) {
    }

    public function find(string $identifier): ?RegistrationInterface
    {
        return $this->ltiRegistrationConverter->convert(
            $this->ltiRegistrationRepository->find($identifier),
        );
    }

    public function findAll(): array
    {
        return array_map(function (LtiRegistration $registration) {
            return $this->ltiRegistrationConverter->convert($registration);
        }, $this->ltiRegistrationRepository->findAll()->all());
    }

    public function findByClientId(string $clientId): ?RegistrationInterface
    {
        return $this->ltiRegistrationConverter->convert(
            current($this->ltiRegistrationRepository->findAll($clientId)->all())
        );
    }

    public function findByPlatformIssuer(string $issuer, ?string $clientId = null): ?RegistrationInterface
    {
        return $this->ltiRegistrationConverter->convert(
            current($this->ltiRegistrationRepository->findAll($clientId, $issuer)->all())
        );
    }

    public function findByToolIssuer(string $issuer, ?string $clientId = null): ?RegistrationInterface
    {
        throw new BadMethodCallException('Not implemented');
    }
}
