<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024-2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Repository;

use Exception;
use InvalidArgumentException;
use OAT\Library\EnvironmentManagementClient\Exception\ConfigurationNotFoundException;
use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Model\Configuration;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;

readonly class ConfigurationRepository implements ConfigurationRepositoryInterface
{
    public const CONFIGURATION_CACHE_PREFIX = 'em_configuration_%s_%s';

    public function __construct(
        private HttpClientInterface $httpClient,
        private CacheInterface $cache,
        private string $authServerGrpcGatewayHost,
        private int $cacheTtl = 300,
    ) {
    }

    public function find(string $tenantId, string $configId): ?Configuration
    {
        return $this->cache->get(
            sprintf(self::CONFIGURATION_CACHE_PREFIX, $tenantId, $configId),
            function (ItemInterface $item) use ($tenantId, $configId) {
                $item->expiresAfter($this->cacheTtl);
                try {
                    $response = $this->httpClient->request(
                        'GET',
                        sprintf(
                            '%s/api/v1/tenants/%s/configurations/%s',
                            $this->authServerGrpcGatewayHost,
                            $tenantId,
                            $configId,
                        ),
                    );
                } catch (Exception $exception) {
                    throw new EnvironmentManagementClientException(
                        sprintf('Failed to fetch configuration with id %s: %s', $configId, $exception->getMessage()),
                        0,
                        $exception,
                    );
                }

                if ($response->getStatusCode() !== 200) {
                    throw new ConfigurationNotFoundException(
                        sprintf(
                            'Configuration with id %s not found. Non-200 status code returned: %d',
                            $configId,
                            $response->getStatusCode(),
                        ),
                    );
                }

                try {
                    return Configuration::fromArray(json_decode($response->getContent(), true));
                } catch (InvalidArgumentException $exception) {
                    throw new ConfigurationNotFoundException(
                        sprintf(
                            'Configuration with id %s is empty.',
                            $configId
                        ),
                        $exception->getCode(),
                        $exception,
                    );
                }
            }
        );
    }
}
