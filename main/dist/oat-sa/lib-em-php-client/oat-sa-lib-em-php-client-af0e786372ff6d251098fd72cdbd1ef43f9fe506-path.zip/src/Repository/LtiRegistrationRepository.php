<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Repository;

use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\LtiRegistrationNotFoundException;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationCollection;
use Psr\Cache\InvalidArgumentException;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

readonly class LtiRegistrationRepository implements LtiRegistrationRepositoryInterface
{
    public const LTI_REGISTRATION_CACHE_PREFIX = 'em_lti_registration_%s';
    public const LTI_REGISTRATIONS_CACHE_PREFIX = 'em_lti_registrations_%s_%s';

    public function __construct(
        private HttpClientInterface $httpClient,
        private CacheInterface $cache,
        private string $authServerGrpcGatewayHost,
        private int $cacheTtl = 300,
    ) {
    }

    /**
     * @throws LtiRegistrationNotFoundException
     * @throws EnvironmentManagementClientException
     * @throws InvalidArgumentException
     */
    public function find(string $identifier): LtiRegistration
    {
        return $this->cache->get(
            sprintf(
                self::LTI_REGISTRATION_CACHE_PREFIX,
                $identifier,
            ),
            function (ItemInterface $item) use ($identifier) {
                try {
                    $item->expiresAfter($this->cacheTtl);

                    $response = $this->httpClient->request(
                        'GET',
                        sprintf(
                            '%s/api/v1/lti-registrations/%s',
                            $this->authServerGrpcGatewayHost,
                            $identifier,
                        ),
                    );

                    if ($response->getStatusCode() !== 200) {
                        throw new LtiRegistrationNotFoundException(
                            sprintf(
                                'LTI registration not found with identifier "%s". Non-200 status code received: %d',
                                $identifier,
                                $response->getStatusCode(),
                            ),
                        );
                    }

                    $data = json_decode($response->getContent(), true);

                    return LtiRegistration::fromArray($data);
                } catch (Throwable $exception) {
                    if ($exception instanceof LtiRegistrationNotFoundException) {
                        throw $exception;
                    }

                    throw new EnvironmentManagementClientException(
                        sprintf(
                            'Failed to fetch LTI registration with identifier "%s": %s',
                            $identifier,
                            $exception->getMessage(),
                        ),
                        0,
                        $exception,
                    );
                }
            }
        );
    }

    /**
     * @throws LtiRegistrationNotFoundException
     * @throws EnvironmentManagementClientException
     * @throws InvalidArgumentException
     */
    public function findAll(
        string $clientId = '',
        string $platformIssuer = '',
    ): ?LtiRegistrationCollection {
        return $this->cache->get(
            sprintf(
                self::LTI_REGISTRATIONS_CACHE_PREFIX,
                $clientId,
                $this->removeSpecialCharactersFromPlatformIssuer($platformIssuer),
            ),
            function (ItemInterface $item) use ($clientId, $platformIssuer) {
                try {
                    $item->expiresAfter($this->cacheTtl);

                    $response = $this->httpClient->request(
                        'GET',
                        sprintf(
                            '%s/api/v1/lti-registrations',
                            $this->authServerGrpcGatewayHost,
                        ),
                        [
                            'query' => [
                                'clientId' => $clientId,
                                'platformIssuer' => $platformIssuer,
                            ],
                        ]
                    );

                    if ($response->getStatusCode() !== 200) {
                        throw new LtiRegistrationNotFoundException(
                            sprintf(
                                'LTI registrations with clientId %s and platformIssuer %s not found. Non-200 status code received: %d',
                                $clientId,
                                $platformIssuer,
                                $response->getStatusCode(),
                            ),
                        );
                    }

                    $content = json_decode($response->getContent(), true);

                    if (!array_key_exists('data', $content)) {
                        throw new LtiRegistrationNotFoundException(
                            sprintf(
                                'LTI registrations with clientId %s and platformIssuer %s not found. No data key in response.',
                                $clientId,
                                $platformIssuer,
                            ),
                        );
                    }

                    return LtiRegistrationCollection::fromArray($content['data']);
                } catch (Throwable $exception) {
                    if ($exception instanceof LtiRegistrationNotFoundException) {
                        throw $exception;
                    }

                    throw new EnvironmentManagementClientException(
                        sprintf(
                            'Failed to fetch LTI registrations with clientId %s and platformIssuer %s: %s',
                            $clientId,
                            $platformIssuer,
                            $exception->getMessage(),
                        ),
                        0,
                        $exception,
                    );
                }
            }
        );
    }

    private function removeSpecialCharactersFromPlatformIssuer(string $platformIssuer): string
    {
        return preg_replace('/[^a-zA-Z0-9]/', '', $platformIssuer);
    }
}
