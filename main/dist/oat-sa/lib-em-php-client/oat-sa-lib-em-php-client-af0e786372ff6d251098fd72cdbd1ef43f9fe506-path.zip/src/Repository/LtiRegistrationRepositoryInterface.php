<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Repository;

use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\LtiRegistrationNotFoundException;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationCollection;

interface LtiRegistrationRepositoryInterface
{
    /**
     * @throws LtiRegistrationNotFoundException
     * @throws EnvironmentManagementClientException
     */
    public function find(string $identifier): LtiRegistration;

    public function findAll(
        string $clientId = '',
        string $platformIssuer = '',
    ): ?LtiRegistrationCollection;
}
