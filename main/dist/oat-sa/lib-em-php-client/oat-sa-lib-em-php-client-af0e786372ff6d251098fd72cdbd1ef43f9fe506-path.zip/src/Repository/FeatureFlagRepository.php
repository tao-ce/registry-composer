<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Repository;

use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\FeatureFlagNotFoundException;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlag;
use Psr\Cache\InvalidArgumentException;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Throwable;

readonly class FeatureFlagRepository implements FeatureFlagRepositoryInterface
{
    public const FEATURE_FLAG_CACHE_PREFIX = 'em_feature_flag_%s_%s';

    public function __construct(
        private HttpClientInterface $httpClient,
        private CacheInterface $cache,
        private string $authServerGrpcGatewayHost,
        private int $cacheTtl = 300,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function find(string $tenantId, string $featureFlagId): ?FeatureFlag
    {
        return $this->cache->get(
            sprintf(self::FEATURE_FLAG_CACHE_PREFIX, $tenantId, $featureFlagId),
            function (ItemInterface $item) use ($tenantId, $featureFlagId) {
                try {
                    $item->expiresAfter($this->cacheTtl);

                    $response = $this->httpClient->request(
                        'GET',
                        sprintf(
                            '%s/api/v1/tenants/%s/feature-flags/%s',
                            $this->authServerGrpcGatewayHost,
                            $tenantId,
                            $featureFlagId,
                        ),
                    );

                    if ($response->getStatusCode() !== 200) {
                        throw new FeatureFlagNotFoundException(
                            sprintf(
                                'Feature flag with id %s not found. Non-200 status code received: %d',
                                $featureFlagId,
                                $response->getStatusCode(),
                            ),
                        );
                    }

                    return FeatureFlag::fromArray(json_decode($response->getContent(), true));
                } catch (Throwable $exception) {
                    if ($exception instanceof FeatureFlagNotFoundException) {
                        throw $exception;
                    }

                    throw new EnvironmentManagementClientException(
                        sprintf('Failed to fetch feature flag with id %s: %s', $featureFlagId, $exception->getMessage()),
                        0,
                        $exception,
                    );
                }
            }
        );
    }
}
