<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Exception\TenantIdNotFoundException;
use Psr\Http\Message\ServerRequestInterface;

interface TenantIdExtractorInterface
{
    /**
     * @throws TenantIdNotFoundException
     * @throws TokenUnauthorizedException
     */
    public function extract(ServerRequestInterface $request): string;
}
