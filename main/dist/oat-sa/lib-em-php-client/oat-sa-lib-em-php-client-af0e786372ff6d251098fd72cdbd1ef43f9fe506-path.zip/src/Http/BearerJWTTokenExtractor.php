<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Signer\Rsa\Sha256;
use Lcobucci\JWT\UnencryptedToken;
use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use Psr\Http\Message\ServerRequestInterface;
use Throwable;

final class BearerJWTTokenExtractor implements JWTTokenExtractorInterface
{
    /**
     * @throws TokenUnauthorizedException
     * @throws EnvironmentManagementClientException
     */
    public function extract(ServerRequestInterface $request): UnencryptedToken
    {
        if (false === $request->hasHeader('authorization')) {
            throw new TokenUnauthorizedException('Missing Authorization header');
        }

        $header = $request->getHeader('authorization');
        $jwt = trim((string)preg_replace('/^\s*Bearer\s/', '', $header[0]));

        try {
            return $this->createConfiguration()->parser()->parse($jwt);
        } catch (Throwable $exception) {
            throw new EnvironmentManagementClientException(
                sprintf('Cannot parse token: %s', $exception->getMessage()),
                $exception->getCode(),
                $exception
            );
        }
    }

    /**
     * No need to validate JWT in any way, since it is already done by the Envoy filter.
     */
    private function createConfiguration(): Configuration
    {
        return Configuration::forSymmetricSigner(
            new Sha256(),
            InMemory::empty()
        );
    }
}
