<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Exception\TenantIdNotFoundException;
use Psr\Http\Message\ServerRequestInterface;

final class TenantIdExtractor implements TenantIdExtractorInterface
{
    private JWTTokenExtractorInterface $tokenExtractor;

    public function __construct(?JWTTokenExtractorInterface $tokenExtractor = null)
    {
        $this->tokenExtractor = $tokenExtractor ?? new BearerJWTTokenExtractor();
    }

    /**
     * @throws TokenUnauthorizedException
     */
    public function extract(ServerRequestInterface $request): string
    {
        $token = $this->tokenExtractor->extract($request);

        if ($token->claims()->has('tenant_id')) {
            return (string)$token->claims()->get('tenant_id');
        }

        throw TenantIdNotFoundException::notInToken();
    }
}
