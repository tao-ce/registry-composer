<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use Psr\Http\Message\ResponseInterface;

interface AuthorizationDetailsMarkerInterface
{
    public const MODE_COOKIE = 'cookie';
    public const MODE_QUERY_PARAMETER = 'queryParameter';
    public const MODE_SESSION_STORAGE = 'sessionStorage';

    public function withAuthDetails(
        ResponseInterface $response,
        string $clientId,
        string $refreshTokenId,
        ?string $userIdentifier = null,
        ?string $userRole = null,
        ?string $cookieDomain = null,
        ?string $ltiToken = null,
        string $mode = self::MODE_COOKIE,
        string $storagePrefix = null,
    ): ResponseInterface;
}
