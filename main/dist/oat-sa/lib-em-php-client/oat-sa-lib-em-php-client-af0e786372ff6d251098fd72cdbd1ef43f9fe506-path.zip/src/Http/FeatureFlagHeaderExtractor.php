<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Model\FeatureFlagCollection;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlagCollectionInterface;
use Psr\Http\Message\MessageInterface;

final readonly class FeatureFlagHeaderExtractor implements FeatureFlagExtractorInterface
{
    private const DEFAULT_HEADER_PREFIX = 'X-Oat-Custom-';

    public function __construct(
        private string $headerPrefix = self::DEFAULT_HEADER_PREFIX,
    ) {
    }

    public function extract(MessageInterface $message): FeatureFlagCollectionInterface
    {
        $featureFlags = new FeatureFlagCollection();
        $headers = $message->getHeaders();

        foreach ($headers as $headerName => $headerValues) {
            if (false !== stripos($headerName, $this->headerPrefix)) {
                $featureFlags->add(
                    str_replace('-', '.', str_ireplace($this->headerPrefix, '', $headerName)),
                    array_pop($headerValues)
                );
            }
        }

        return $featureFlags;
    }
}
