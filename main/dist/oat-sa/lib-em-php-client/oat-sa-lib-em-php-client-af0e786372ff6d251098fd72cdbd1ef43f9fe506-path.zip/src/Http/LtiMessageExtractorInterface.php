<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Exception\RegistrationIdNotFoundException;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayloadInterface;
use Psr\Http\Message\ServerRequestInterface;

interface LtiMessageExtractorInterface
{
    /**
     * @throws RegistrationIdNotFoundException
     * @throws TokenUnauthorizedException
     */
    public function extract(ServerRequestInterface $request): LtiMessagePayloadInterface;
}
