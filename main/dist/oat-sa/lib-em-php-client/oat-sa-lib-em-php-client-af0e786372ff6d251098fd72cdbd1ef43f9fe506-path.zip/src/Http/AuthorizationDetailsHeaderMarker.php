<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use Psr\Http\Message\ResponseInterface;

final class AuthorizationDetailsHeaderMarker implements AuthorizationDetailsMarkerInterface
{
    private const DEFAULT_HEADER_NAME = 'X-OAT-WITH-AUTH-DETAILS';

    public function withAuthDetails(
        ResponseInterface $response,
        string $clientId,
        string $refreshTokenId,
        ?string $userIdentifier = null,
        ?string $userRole = null,
        ?string $cookieDomain = null,
        ?string $ltiToken = null,
        string $mode = self::MODE_COOKIE,
        string $storagePrefix = null,
    ): ResponseInterface {
        return $response->withHeader(self::DEFAULT_HEADER_NAME, json_encode([
            'clientId' => $clientId,
            'refreshTokenId' => $refreshTokenId,
            'userIdentifier' => $userIdentifier,
            'userRole' => $userRole,
            'cookieDomain' => $cookieDomain,
            'ltiToken' => $ltiToken,
            'mode' => $mode,
            'storagePrefix' => $storagePrefix,
        ]));
    }
}
