<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Exception\LtiMessageExtractFailedException;
use OAT\Library\Lti1p3Core\Security\Jwt\Token;
use Psr\Http\Message\ServerRequestInterface;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayload;
use OAT\Library\Lti1p3Core\Message\Payload\LtiMessagePayloadInterface;

final class LtiMessageExtractor implements LtiMessageExtractorInterface
{
    private JWTTokenExtractorInterface $tokenExtractor;

    public function __construct(?JWTTokenExtractorInterface $tokenExtractor = null)
    {
        $this->tokenExtractor = $tokenExtractor ?? new BearerJWTTokenExtractor();
    }

    /**
     * @throws TokenUnauthorizedException
     */
    public function extract(ServerRequestInterface $request): LtiMessagePayloadInterface
    {
        if (!empty($request->hasHeader("Authorization"))) {
            $token = $this->tokenExtractor->extract($request);

            return new LtiMessagePayload(new Token($token));
        }

        throw LtiMessageExtractFailedException::unableToExtractLtiMessage();
    }
}
