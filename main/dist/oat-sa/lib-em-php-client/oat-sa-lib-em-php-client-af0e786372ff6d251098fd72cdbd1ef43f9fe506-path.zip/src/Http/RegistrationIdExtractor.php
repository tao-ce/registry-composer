<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Http;

use OAT\Library\EnvironmentManagementClient\Exception\TokenUnauthorizedException;
use OAT\Library\EnvironmentManagementClient\Exception\RegistrationIdNotFoundException;
use Psr\Http\Message\ServerRequestInterface;

final class RegistrationIdExtractor implements RegistrationIdExtractorInterface
{
    private JWTTokenExtractorInterface $tokenExtractor;

    public function __construct(?JWTTokenExtractorInterface $tokenExtractor = null)
    {
        $this->tokenExtractor = $tokenExtractor ?? new BearerJWTTokenExtractor();
    }

    /**
     * @throws TokenUnauthorizedException
     */
    public function extract(ServerRequestInterface $request): string
    {
        $token = $this->tokenExtractor->extract($request);

        if ($token->claims()->has('registration_id')) {
            return (string)$token->claims()->get('registration_id');
        }

        throw RegistrationIdNotFoundException::notInToken();
    }
}
