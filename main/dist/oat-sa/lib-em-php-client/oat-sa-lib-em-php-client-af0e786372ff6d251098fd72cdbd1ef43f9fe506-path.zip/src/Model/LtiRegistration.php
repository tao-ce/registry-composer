<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

readonly class LtiRegistration implements LtiRegistrationInterface
{
    public function __construct(
        private string $id,
        private string $clientId,
        private string $platformId,
        private string $toolId,
        private array $deploymentIds,
        private ?string $platformJwksUrl = null,
        private ?string $toolJwksUrl = null,
        private ?LtiKeyChainInterface $platformKeyChain = null,
        private ?LtiKeyChainInterface $toolKeyChain = null,
        private ?LtiPlatformInterface $ltiPlatform = null,
        private ?LtiToolInterface $ltiTool = null,
        private ?string $tenantId = null,
    ) {
    }

    public static function fromArray(array $registration): self
    {
        return new self(
            $registration['id'],
            $registration['clientId'],
            $registration['platformId'],
            $registration['toolId'],
            $registration['deploymentIds'],
            $registration['platformJwksUrl'] ?? null,
            $registration['toolJwksUrl'] ?? null,
            array_key_exists('platformKeyChain', $registration) && !empty($registration['platformKeyChain']) ? LtiKeyChain::fromArray($registration['platformKeyChain']) : null,
            array_key_exists('toolKeyChain', $registration) && !empty($registration['toolKeyChain']) ? LtiKeyChain::fromArray($registration['toolKeyChain']) : null,
            array_key_exists('platform', $registration) && !empty($registration['platform']) ? LtiPlatform::fromArray($registration['platform']) : null,
            array_key_exists('tool', $registration) && !empty($registration['tool']) ? LtiTool::fromArray($registration['tool']) : null,
            $registration['tenantId'] ?? null,
        );
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getClientId(): string
    {
        return $this->clientId;
    }

    public function getPlatformId(): string
    {
        return $this->platformId;
    }

    public function getToolId(): string
    {
        return $this->toolId;
    }

    public function getDeploymentIds(): array
    {
        return $this->deploymentIds;
    }

    public function getPlatformJwksUrl(): ?string
    {
        return $this->platformJwksUrl;
    }

    public function getToolJwksUrl(): ?string
    {
        return $this->toolJwksUrl;
    }

    public function getPlatformKeyChain(): ?LtiKeyChainInterface
    {
        return $this->platformKeyChain;
    }

    public function getToolKeyChain(): ?LtiKeyChainInterface
    {
        return $this->toolKeyChain;
    }

    public function getLtiPlatform(): ?LtiPlatformInterface
    {
        return $this->ltiPlatform;
    }

    public function getLtiTool(): ?LtiToolInterface
    {
        return $this->ltiTool;
    }

    public function getTenantId(): ?string
    {
        return $this->tenantId;
    }
}
