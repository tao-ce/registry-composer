<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use OAT\Library\Lti1p3Core\Registration\RegistrationInterface;

interface TenantAwareRegistrationInterface extends RegistrationInterface
{
    public function getTenantIdentifier();

    public static function fromBaseRegistration(RegistrationInterface $registration, ?string $tenantId = null): TenantAwareRegistrationInterface;
}
