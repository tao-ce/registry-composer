<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

interface LtiKeyChainInterface
{
    public function getId(): string;
    public function getKeySetName(): string;
    public function getPublicKey(): string;
    public function getPrivateKey(): ?string;
    public function getPrivateKeyPassphrase(): ?string;
}
