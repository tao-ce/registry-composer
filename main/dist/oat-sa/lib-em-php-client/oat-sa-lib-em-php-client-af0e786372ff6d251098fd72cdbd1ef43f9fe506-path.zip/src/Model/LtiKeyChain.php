<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

readonly class LtiKeyChain implements LtiKeyChainInterface
{
    public function __construct(
        private string $id,
        private string $keySetName,
        private string $publicKey,
        private ?string $privateKey = null,
        private ?string $privateKeyPassphrase = null,
    ) {
    }

    public static function fromArray(array $ltiKeyChain): self
    {
        return new self(
            $ltiKeyChain['id'],
            $ltiKeyChain['keySetName'],
            $ltiKeyChain['publicKey'],
            $ltiKeyChain['privateKey'] ?? null,
            $ltiKeyChain['privateKeyPassphrase'] ?? null,
        );
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getKeySetName(): string
    {
        return $this->keySetName;
    }

    public function getPublicKey(): string
    {
        return $this->publicKey;
    }

    public function getPrivateKey(): ?string
    {
        return $this->privateKey;
    }

    public function getPrivateKeyPassphrase(): ?string
    {
        return $this->privateKeyPassphrase;
    }
}
