<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

readonly class LtiTool implements LtiToolInterface
{
    public function __construct(
        private string $id,
        private string $name,
        private string $audience,
        private string $oidcInitiationUrl,
        private ?string $launchUrl = null,
        private ?string $deepLinkingUrl = null,
        private bool $isInternal = false,
    ) {
    }

    public static function fromArray(array $ltiTool): self
    {
        return new LtiTool(
            $ltiTool['id'],
            $ltiTool['name'],
            $ltiTool['audience'],
            $ltiTool['oidcInitiationUrl'],
            $ltiTool['launchUrl'] ?? null,
            $ltiTool['deepLinkingUrl'] ?? null,
            $ltiTool['isInternal'] ?? false,
        );
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getAudience(): string
    {
        return $this->audience;
    }

    public function getOidcInitiationUrl(): string
    {
        return $this->oidcInitiationUrl;
    }

    public function getLaunchUrl(): ?string
    {
        return $this->launchUrl;
    }

    public function getDeepLinkingUrl(): ?string
    {
        return $this->deepLinkingUrl;
    }

    public function isInternal(): bool
    {
        return $this->isInternal;
    }
}
