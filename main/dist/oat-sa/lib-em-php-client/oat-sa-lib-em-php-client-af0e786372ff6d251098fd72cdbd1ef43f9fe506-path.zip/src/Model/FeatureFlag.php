<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use InvalidArgumentException;

readonly class FeatureFlag implements FeatureFlagInterface
{
    private string $name;
    private string $value;

    public function __construct(string $name, string $value)
    {
        if ('' === $name) {
            throw new InvalidArgumentException('Flag name cannot be empty.');
        }

        if ('' === $value) {
            throw new InvalidArgumentException('Flag value cannot be empty.');
        }

        $this->name = $name;
        $this->value = $value;
    }

    public static function fromArray(array $data): self
    {
        return new self($data['name'], $data['value']);
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getValue(): string
    {
        return $this->value;
    }
}
