<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use ArrayIterator;
use OutOfBoundsException;
use Traversable;

class FeatureFlagCollection implements FeatureFlagCollectionInterface
{
    /** @var FeatureFlagInterface[] */
    private array $flags = [];

    public function add(string $name, string $value): self
    {
        $this->flags[strtolower($name)] = new FeatureFlag($name, $value);

        return $this;
    }

    public function has(string $flagName): bool
    {
        return array_key_exists(strtolower($flagName), $this->flags);
    }

    public function get(string $flagName): FeatureFlagInterface
    {
        if (!$this->has($flagName)) {
            throw new OutOfBoundsException(sprintf('Flag %s does not exist.', $flagName));
        }

        return $this->flags[strtolower($flagName)];
    }

    /**
     * @return FeatureFlagInterface[]
     */
    public function all(): array
    {
        return array_values($this->flags);
    }

    public function getIterator(): Traversable
    {
        return new ArrayIterator($this->flags);
    }

    public function count(): int
    {
        return count($this->flags);
    }

    public function isEmpty(): bool
    {
        return 0 === $this->count();
    }
}