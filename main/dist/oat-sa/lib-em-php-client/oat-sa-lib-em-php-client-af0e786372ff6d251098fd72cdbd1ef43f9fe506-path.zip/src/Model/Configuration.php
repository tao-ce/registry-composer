<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use InvalidArgumentException;

readonly class Configuration implements ConfigurationInterface
{
    private string $name;
    private string|array $value;

    public function __construct(string $name, string|array $value)
    {
        if ('' === $name) {
            throw new InvalidArgumentException('Configuration name cannot be empty.');
        }

        if ('' === $value) {
            throw new InvalidArgumentException('Configuration value cannot be empty.');
        }

        $this->name = $name;
        $this->value = $value;
    }

    public static function fromArray(array $data): self
    {
        return new self($data['name'], $data['value']);
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getStringValue(): string
    {
        if (!is_string($this->value)) {
            throw new InvalidArgumentException(sprintf(
                'Configuration value is not a string. Its type is "%s".',
                gettype($this->value),
            ));
        }

        return $this->value;
    }

    public function getArrayValue(): array
    {
        if (!is_array($this->value)) {
            throw new InvalidArgumentException(sprintf(
                'Configuration value is not an array. Its type is "%s".',
                gettype($this->value),
            ));
        }

        return $this->value;
    }
}
