<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

interface LtiRegistrationInterface
{
    public function getId(): string;
    public function getClientId(): string;
    public function getPlatformId(): string;
    public function getToolId(): string;
    public function getDeploymentIds(): array;
    public function getPlatformJwksUrl(): ?string;
    public function getToolJwksUrl(): ?string;
    public function getPlatformKeyChain(): ?LtiKeyChainInterface;
    public function getToolKeyChain(): ?LtiKeyChainInterface;
    public function getLtiPlatform(): ?LtiPlatformInterface;
    public function getLtiTool(): ?LtiToolInterface;
    public function getTenantId(): ?string;
}
