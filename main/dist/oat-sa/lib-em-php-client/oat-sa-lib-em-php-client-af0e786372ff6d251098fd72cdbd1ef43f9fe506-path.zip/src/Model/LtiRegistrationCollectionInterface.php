<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use Countable;
use IteratorAggregate;

interface LtiRegistrationCollectionInterface extends IteratorAggregate, Countable
{
    public function add(LtiRegistrationInterface $registration): self;
    public function has(string $registrationId): bool;
    public function get(string $registrationId): LtiRegistrationInterface;
    public function isEmpty(): bool;
    public function all(): array;
}
