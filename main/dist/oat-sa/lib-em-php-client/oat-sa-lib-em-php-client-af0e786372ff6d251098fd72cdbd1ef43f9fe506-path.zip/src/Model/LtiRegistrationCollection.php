<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use ArrayIterator;
use OutOfBoundsException;
use Traversable;

class LtiRegistrationCollection implements LtiRegistrationCollectionInterface
{
    /** @var LtiRegistrationInterface[] */
    private array $registrations = [];

    public static function fromArray(array $data): self
    {
        $collection = new self();

        foreach ($data as $registration) {
            $collection->add(LtiRegistration::fromArray($registration));
        }

        return $collection;
    }

    public function add(LtiRegistrationInterface $registration): self
    {
        $this->registrations[$registration->getId()] = $registration;

        return $this;
    }

    public function has(string $registrationId): bool
    {
        return array_key_exists($registrationId, $this->registrations);
    }

    public function get(string $registrationId): LtiRegistrationInterface
    {
        if (!$this->has($registrationId)) {
            throw new OutOfBoundsException(sprintf('LTI Registration %s does not exist.', $registrationId));
        }

        return $this->registrations[$registrationId];
    }

    /**
     * @return ArrayIterator
     */
    public function getIterator(): Traversable
    {
        return new ArrayIterator($this->registrations);
    }

    public function count(): int
    {
        return count($this->registrations);
    }

    public function isEmpty(): bool
    {
        return 0 === $this->count();
    }

    /**
     * @return LtiRegistrationInterface[]
     */
    public function all(): array
    {
        return array_values($this->registrations);
    }
}
