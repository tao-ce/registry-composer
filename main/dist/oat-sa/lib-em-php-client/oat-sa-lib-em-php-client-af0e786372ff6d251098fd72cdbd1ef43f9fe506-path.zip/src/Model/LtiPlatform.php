<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

readonly class LtiPlatform implements LtiPlatformInterface
{
    public function __construct(
        private string $id,
        private string $name,
        private string $audience,
        private ?string $oidcAuthenticationUrl = null,
        private ?string $oauth2AccessTokenUrl = null,
        private bool $isInternal = false,
    ) {
    }

    public static function fromArray(array $ltiPlatform): self
    {
        return new self(
            $ltiPlatform['id'],
            $ltiPlatform['name'],
            $ltiPlatform['audience'],
            $ltiPlatform['oidcAuthenticationUrl'] ?? null,
            $ltiPlatform['oauth2AccessTokenUrl'] ?? null,
            $ltiPlatform['isInternal'] ?? false,
        );
    }

    public function getId(): string
    {
        return $this->id;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getAudience(): string
    {
        return $this->audience;
    }

    public function getOidcAuthenticationUrl(): ?string
    {
        return $this->oidcAuthenticationUrl;
    }

    public function getOauth2AccessTokenUrl(): ?string
    {
        return $this->oauth2AccessTokenUrl;
    }

    public function isInternal(): bool
    {
        return $this->isInternal;
    }
}
