<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use OAT\Library\Lti1p3Core\Platform\PlatformInterface;
use OAT\Library\Lti1p3Core\Registration\Registration as BaseRegistration;
use OAT\Library\Lti1p3Core\Registration\RegistrationInterface;
use OAT\Library\Lti1p3Core\Security\Key\KeyChainInterface;
use OAT\Library\Lti1p3Core\Tool\ToolInterface;

class TenantAwareRegistration extends BaseRegistration implements TenantAwareRegistrationInterface
{
    private ?string $tenantId;

    public function __construct(
        string $identifier,
        string $clientId,
        PlatformInterface $platform,
        ToolInterface $tool,
        array $deploymentIds,
        ?KeyChainInterface $platformKeyChain = null,
        ?KeyChainInterface $toolKeyChain = null,
        ?string $platformJwksUrl = null,
        ?string $toolJwksUrl = null,
        ?string $tenantId = null
    ) {
        parent::__construct(
            $identifier,
            $clientId,
            $platform,
            $tool,
            $deploymentIds,
            $platformKeyChain,
            $toolKeyChain,
            $platformJwksUrl,
            $toolJwksUrl
        );

        $this->tenantId = $tenantId;
    }
    public function getTenantIdentifier(): ?string
    {
        return $this->tenantId;
    }

    public static function fromBaseRegistration(RegistrationInterface $registration, ?string $tenantId = null): TenantAwareRegistrationInterface
    {
        return new TenantAwareRegistration(
            $registration->getIdentifier(),
            $registration->getClientId(),
            $registration->getPlatform(),
            $registration->getTool(),
            $registration->getDeploymentIds(),
            $registration->getPlatformKeyChain(),
            $registration->getToolKeyChain(),
            $registration->getPlatformJwksUrl(),
            $registration->getToolJwksUrl(),
            $tenantId
        );
    }
}
