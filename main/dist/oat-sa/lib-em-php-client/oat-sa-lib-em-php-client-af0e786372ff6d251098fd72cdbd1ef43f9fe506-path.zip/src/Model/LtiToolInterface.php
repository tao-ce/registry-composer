<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

interface LtiToolInterface
{
    public function getId(): string;
    public function getName(): string;
    public function getAudience(): string;
    public function getOidcInitiationUrl(): string;
    public function getLaunchUrl(): ?string;
    public function getDeepLinkingUrl(): ?string;
    public function isInternal(): bool;
}
