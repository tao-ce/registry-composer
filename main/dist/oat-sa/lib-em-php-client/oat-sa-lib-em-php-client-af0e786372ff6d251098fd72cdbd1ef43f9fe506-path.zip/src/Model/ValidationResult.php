<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Model;

use Oat\Envmgmt\Common\ValidationResult as ProtoValidationResult;

final class ValidationResult
{
    private bool $isValid;
    private string $errorMessage;

    public function __construct(
        bool $isValid,
        string $errorMessage,
    ) {
        $this->isValid = $isValid;
        $this->errorMessage = $errorMessage;
    }

    public static function fromProtobuf(ProtoValidationResult $protoValidationResult): self
    {
        return new self(
            $protoValidationResult->getIsValid(),
            $protoValidationResult->getErrorMsg(),
        );
    }

    /**
     * @return bool
     */
    public function isValid(): bool
    {
        return $this->isValid;
    }

    /**
     * @return string
     */
    public function getErrorMessage(): string
    {
        return $this->errorMessage;
    }
}
