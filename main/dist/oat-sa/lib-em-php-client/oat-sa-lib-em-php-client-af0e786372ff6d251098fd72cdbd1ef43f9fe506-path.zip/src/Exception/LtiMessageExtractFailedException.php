<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Exception;

final class LtiMessageExtractFailedException extends EnvironmentManagementClientException
{
    public static function unableToExtractLtiMessage(): self
    {
        return new self('Not able to parse Lti message from JWT token.');
    }
}
