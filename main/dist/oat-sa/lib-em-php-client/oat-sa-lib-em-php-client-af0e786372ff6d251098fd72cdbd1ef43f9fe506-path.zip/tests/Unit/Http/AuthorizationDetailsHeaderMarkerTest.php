<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Http;

use Nyholm\Psr7\Factory\Psr17Factory;
use OAT\Library\EnvironmentManagementClient\Http\AuthorizationDetailsHeaderMarker;
use PHPUnit\Framework\TestCase;

final class AuthorizationDetailsHeaderMarkerTest extends TestCase
{
    public function testAuthDetailsHeaderAdded(): void
    {
        $message = (new Psr17Factory())->createResponse();

        $marker = new AuthorizationDetailsHeaderMarker();
        $message = $marker->withAuthDetails($message, "client1", "refreshToken1", "userIdentifier1", "userRole1", "cookieDomain1", "ltiToken1", "cookie");

        $this->assertTrue($message->hasHeader('X-OAT-WITH-AUTH-DETAILS'));

        $withAuthDetails = $message->getHeader('X-OAT-WITH-AUTH-DETAILS')[0];

        $this->assertNotNull(
            $withAuthDetails,
            "withAuthDetails is null"
        );

        $res_array = (array)json_decode($withAuthDetails);

        $this->assertArrayHasKey('clientId', $res_array);
        $this->assertEquals('client1', $res_array['clientId']);
        $this->assertArrayHasKey('refreshTokenId', $res_array);
        $this->assertEquals('refreshToken1', $res_array['refreshTokenId']);
        $this->assertEquals('userIdentifier1', $res_array['userIdentifier']);
        $this->assertEquals('userRole1', $res_array['userRole']);
        $this->assertEquals('cookieDomain1', $res_array['cookieDomain']);
        $this->assertEquals('ltiToken1', $res_array['ltiToken']);
        $this->assertEquals('cookie', $res_array['mode']);
    }
}
