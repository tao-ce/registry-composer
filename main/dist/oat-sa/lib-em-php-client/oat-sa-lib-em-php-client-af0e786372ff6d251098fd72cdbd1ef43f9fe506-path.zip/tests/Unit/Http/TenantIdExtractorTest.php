<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Http;

use Lcobucci\JWT\Token\DataSet;
use Lcobucci\JWT\Token\Plain;
use Lcobucci\JWT\UnencryptedToken;
use Nyholm\Psr7\Factory\Psr17Factory;
use OAT\Library\EnvironmentManagementClient\Exception\TenantIdNotFoundException;
use OAT\Library\EnvironmentManagementClient\Http\JWTTokenExtractorInterface;
use OAT\Library\EnvironmentManagementClient\Http\TenantIdExtractor;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

final class TenantIdExtractorTest extends TestCase
{
    private TenantIdExtractor $subject;

    /** @var JWTTokenExtractorInterface|MockObject */
    private $jwtExtractorMock;

    protected function setUp(): void
    {
        $this->jwtExtractorMock = $this->createMock(JWTTokenExtractorInterface::class);
        $this->subject = new TenantIdExtractor($this->jwtExtractorMock);
    }

    public function testExtractTenantIdSuccessfully(): void
    {
        $request = (new Psr17Factory())->createServerRequest('GET', 'http://example.test');

        $tokenMock = $this->createMock(UnencryptedToken::class);
        $claims = new DataSet(['tenant_id' => 'tenant-2'], '');

        $tokenMock->expects($this->exactly(2))
            ->method('claims')
            ->willReturn($claims);

        $this->jwtExtractorMock->expects($this->once())
            ->method('extract')
            ->with($request)
            ->willReturn($tokenMock);

        $tenantId = $this->subject->extract($request);

        $this->assertEquals('tenant-2', $tenantId);
    }

    public function testExtractTenantIdThrowsExceptionIfItNotPresentInToken(): void
    {
        $this->expectException(TenantIdNotFoundException::class);
        $this->expectExceptionMessage('Tenant Id not found in JWT token.');

        $request = (new Psr17Factory())->createServerRequest('GET', 'http://example.test');

        $tokenMock = $this->createMock(UnencryptedToken::class);
        $claims = new DataSet([], '');

        $tokenMock->expects($this->once())
            ->method('claims')
            ->willReturn($claims);

        $this->jwtExtractorMock->expects($this->once())
            ->method('extract')
            ->with($request)
            ->willReturn($tokenMock);

        $this->subject->extract($request);
    }
}
