<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Http;

use Lcobucci\JWT\Token\DataSet;
use Lcobucci\JWT\UnencryptedToken;
use Nyholm\Psr7\Factory\Psr17Factory;
use OAT\Library\EnvironmentManagementClient\Exception\RegistrationIdNotFoundException;
use OAT\Library\EnvironmentManagementClient\Http\JWTTokenExtractorInterface;
use OAT\Library\EnvironmentManagementClient\Http\RegistrationIdExtractor;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

final class RegistrationIdExtractorTest extends TestCase
{
    private RegistrationIdExtractor $subject;

    /** @var JWTTokenExtractorInterface|MockObject */
    private $jwtExtractorMock;

    protected function setUp(): void
    {
        $this->jwtExtractorMock = $this->createMock(JWTTokenExtractorInterface::class);
        $this->subject = new RegistrationIdExtractor($this->jwtExtractorMock);
    }

    public function testExtractRegistrationIdSuccessfully(): void
    {
        $request = (new Psr17Factory())->createServerRequest('GET', 'http://example.test');

        $tokenMock = $this->createMock(UnencryptedToken::class);
        $claims = new DataSet(['registration_id' => 'reg-2'], '');

        $tokenMock->expects($this->exactly(2))
            ->method('claims')
            ->willReturn($claims);

        $this->jwtExtractorMock->expects($this->once())
            ->method('extract')
            ->with($request)
            ->willReturn($tokenMock);

        $tenantId = $this->subject->extract($request);

        $this->assertEquals('reg-2', $tenantId);
    }

    public function testExtractRegistrationIdThrowsExceptionIfItNotPresentInToken(): void
    {
        $this->expectException(RegistrationIdNotFoundException::class);
        $this->expectExceptionMessage('LTI Registration Id not found in JWT token.');

        $request = (new Psr17Factory())->createServerRequest('GET', 'http://example.test');

        $tokenMock = $this->createMock(UnencryptedToken::class);
        $claims = new DataSet([], '');

        $tokenMock->expects($this->once())
            ->method('claims')
            ->willReturn($claims);

        $this->jwtExtractorMock->expects($this->once())
            ->method('extract')
            ->with($request)
            ->willReturn($tokenMock);

        $this->subject->extract($request);
    }
}
