<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Model;

use OAT\Library\EnvironmentManagementClient\Model\LtiKeyChain;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationCollection;
use OutOfBoundsException;
use PHPUnit\Framework\TestCase;

final class LtiRegistrationCollectionTest extends TestCase
{
    public function testRegistrationCollectionLifeCycle(): void
    {
        $collection = new LtiRegistrationCollection();

        $this->assertEmpty($collection->all());
        $this->assertEmpty($collection->getIterator());
        $this->assertEquals(0, $collection->count());
        $this->assertTrue($collection->isEmpty());

        $reg1 = new LtiRegistration(
            'reg-1',
            'client-1',
            'platform-1',
            'tool-1',
            ['deploy-1', 'deploy-2'],
            'platform-url',
            'tool-url',
            new LtiKeyChain(
                'platform-key-1',
                'platform-keys',
                'public-key',
                'private-key',
                'private-pass'
            ),
            new LtiKeyChain(
                'tool-key-1',
                'tool-keys',
                'public-key',
                'private-key',
                'private-pass'
            ),
            null,
            null,
            null
        );

        $collection->add($reg1);

        $this->assertEquals(1, $collection->count());
        $this->assertFalse($collection->isEmpty());
        $this->assertTrue($collection->has('reg-1'));
        $this->assertEquals($reg1, $collection->get('reg-1'));
        $this->assertEquals([$reg1], $collection->all());
    }

    public function testRegistrationCollectionGetThrowsExceptionWhenFlagNotExist(): void
    {
        $this->expectException(OutOfBoundsException::class);
        $this->expectExceptionMessage('LTI Registration FAKE-reg-1 does not exist.');

        $collection = new LtiRegistrationCollection();
        $collection->get('FAKE-reg-1');
    }

    public function testFromArray(): void
    {
        $data = [
            [
                'id' => 'reg-1',
                'clientId' => 'client-1',
                'platformIssuer' => 'platform-1',
                'platformId' => 'platform-1',
                'toolId' => 'tool-1',
                'deploymentIds' => ['deploy-1', 'deploy-2'],
                'platformUrl' => 'platform-url',
                'toolUrl' => 'tool-url',
                'platformKeyChain' => [
                    'id' => 'platform-key-1',
                    'keySetName' => 'platform-keys',
                    'publicKey' => 'public-key',
                    'privateKey' => 'private-key',
                    'privateKeyPassphrase' => 'private-pass',
                ],
                'toolKeyChain' => [
                    'id' => 'tool-key-1',
                    'keySetName' => 'tool-keys',
                    'publicKey' => 'public-key',
                    'privateKey' => 'private-key',
                    'privateKeyPassphrase' => 'private-pass',
                ],
                'ltiTool' => [
                    'id' => 'tool-1',
                    'name' => 'tool-name',
                    'audience' => 'tool-audience',
                    'oidcInitiationUrl' => 'tool-init-url',
                    'launchUrl' => 'tool-launch-url',
                    'deepLinkingUrl' => 'tool-deep-link-url',
                    'isInternal' => true,
                ],
                'ltiPlatform' => [
                    'id' => 'platform-1',
                    'name' => 'platform-name',
                    'audience' => 'platform-audience',
                    'oidcAuthenticationUrl' => 'platform-auth-url',
                    'oauth2AccessTokenUrl' => 'platform-token-url',
                    'isInternal' => true,
                ],
            ],
        ];

        $collection = LtiRegistrationCollection::fromArray($data);

        $this->assertInstanceOf(LtiRegistrationCollection::class, $collection);
        $this->assertEquals(1, $collection->count());
        $this->assertFalse($collection->isEmpty());
        $this->assertTrue($collection->has('reg-1'));
    }
}
