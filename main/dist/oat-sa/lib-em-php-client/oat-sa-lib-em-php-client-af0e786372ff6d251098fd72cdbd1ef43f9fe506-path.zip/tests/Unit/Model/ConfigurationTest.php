<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Model;

use InvalidArgumentException;
use OAT\Library\EnvironmentManagementClient\Model\Configuration;
use PHPUnit\Framework\TestCase;

class ConfigurationTest extends TestCase
{
    private Configuration $subject;

    public function testConstruct(): void
    {
        $this->subject = new Configuration('name', 'value');
        $this->assertInstanceOf(Configuration::class, $this->subject);
    }

    public function testConstructWithEmptyName(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Configuration name cannot be empty.');
        $this->subject = new Configuration('', 'value');
    }

    public function testConstructWithEmptyValue(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Configuration value cannot be empty.');
        $this->subject = new Configuration('name', '');
    }

    public function testGetName(): void
    {
        $this->subject = new Configuration('name', 'value');
        $this->assertEquals('name', $this->subject->getName());
    }

    public function testGetStringValue(): void
    {
        $this->subject = new Configuration('name', 'value');
        $this->assertEquals('value', $this->subject->getStringValue());
    }

    public function testGetStringValueWithWrongType(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Configuration value is not a string. Its type is "array".');
        $this->subject = new Configuration('name', ['value']);
        $this->subject->getStringValue();
    }

    public function testGetArrayValue(): void
    {
        $this->subject = new Configuration('name', ['value']);
        $this->assertEquals(['value'], $this->subject->getArrayValue());
    }

    public function testGetArrayValueWithWrongType(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Configuration value is not an array. Its type is "string".');
        $this->subject = new Configuration('name', 'value');
        $this->subject->getArrayValue();
    }

    public function testFromArray(): void
    {
        $data = ['name' => 'name', 'value' => 'value'];
        $this->subject = Configuration::fromArray($data);

        $this->assertInstanceOf(Configuration::class, $this->subject);
        $this->assertEquals('name', $this->subject->getName());
        $this->assertEquals('value', $this->subject->getStringValue());
    }
}