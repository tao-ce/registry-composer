<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Model;

use OAT\Library\EnvironmentManagementClient\Model\FeatureFlag;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlagCollection;
use OutOfBoundsException;
use PHPUnit\Framework\TestCase;

final class FeatureFlagCollectionTest extends TestCase
{
    public function testFlagCollectionLifeCycle(): void
    {
        $collection = new FeatureFlagCollection();

        $this->assertEmpty($collection->all());
        $this->assertEmpty($collection->getIterator());
        $this->assertEquals(0, $collection->count());
        $this->assertTrue($collection->isEmpty());

        $collection->add('flAG-1', 'value-1');

        $this->assertEquals(1, $collection->count());
        $this->assertFalse($collection->isEmpty());
        $this->assertTrue($collection->has('flag-1'));
        $this->assertEquals(new FeatureFlag('flAG-1', 'value-1'), $collection->get('flAG-1'));
        $this->assertEquals([new FeatureFlag('flAG-1', 'value-1')], $collection->all());
    }

    public function testFlagCollectionGetThrowsExceptionWhenFlagNotExist(): void
    {
        $this->expectException(OutOfBoundsException::class);
        $this->expectExceptionMessage('Flag FAKE-flag-1 does not exist.');

        $collection = new FeatureFlagCollection();
        $collection->get('FAKE-flag-1');
    }
}
