<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Model;

use OAT\Library\EnvironmentManagementClient\Model\TenantAwareRegistration;
use OAT\Library\EnvironmentManagementClient\Model\TenantAwareRegistrationInterface;
use OAT\Library\Lti1p3Core\Platform\PlatformInterface;
use OAT\Library\Lti1p3Core\Registration\Registration;
use OAT\Library\Lti1p3Core\Security\Key\KeyChainInterface;
use OAT\Library\Lti1p3Core\Tool\ToolInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class TenantAwareRegistrationTest extends TestCase
{
    private PlatformInterface|MockObject $platformMock;
    private ToolInterface|MockObject $toolMock;
    private KeyChainInterface|MockObject $platformKeyChainMock;
    private KeyChainInterface|MockObject $toolKeyChainMock;

    protected function setUp(): void
    {
        $this->platformMock = $this->createMock(PlatformInterface::class);
        $this->toolMock = $this->createMock(ToolInterface::class);
        $this->platformKeyChainMock = $this->createMock(KeyChainInterface::class);
        $this->toolKeyChainMock = $this->createMock(KeyChainInterface::class);
    }

    public function testGetters(): void
    {
        $registration = new TenantAwareRegistration(
            'id',
            'clientId',
            $this->platformMock,
            $this->toolMock,
            ['1'],
            $this->platformKeyChainMock,
            $this->toolKeyChainMock,
            'platformJwksUrl',
            'toolJwksUrl',
            'tenantId'
        );

        $this->assertRegistrationGetters($registration);
    }

    public function testFromBaseRegistration(): void
    {
        $baseRegistration = new Registration(
            'id',
            'clientId',
            $this->platformMock,
            $this->toolMock,
            ['1'],
            $this->platformKeyChainMock,
            $this->toolKeyChainMock,
            'platformJwksUrl',
            'toolJwksUrl'
        );

        $registration = TenantAwareRegistration::fromBaseRegistration($baseRegistration, 'tenantId');

        $this->assertRegistrationGetters($registration);
    }

    private function assertRegistrationGetters(TenantAwareRegistrationInterface $registration): void
    {
        $this->assertSame('id', $registration->getIdentifier());
        $this->assertSame('clientId', $registration->getClientId());
        $this->assertSame($this->platformMock, $registration->getPlatform());
        $this->assertSame($this->toolMock, $registration->getTool());
        $this->assertSame(['1'], $registration->getDeploymentIds());
        $this->assertSame($this->platformKeyChainMock, $registration->getPlatformKeyChain());
        $this->assertSame($this->toolKeyChainMock, $registration->getToolKeyChain());
        $this->assertSame('platformJwksUrl', $registration->getPlatformJwksUrl());
        $this->assertSame('toolJwksUrl', $registration->getToolJwksUrl());
        $this->assertSame('tenantId', $registration->getTenantIdentifier());
    }
}
