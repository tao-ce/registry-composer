<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Model;

use InvalidArgumentException;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlag;
use PHPUnit\Framework\TestCase;

final class FeatureFlagTest extends TestCase
{
    /**
     * @dataProvider invalidDataProvider
     */
    public function testFeatureFlagWithInvalidData(string $name, string $value, string $expectedExceptionMessage): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage($expectedExceptionMessage);

        new FeatureFlag($name, $value);
    }

    public function invalidDataProvider(): array
    {
        return [
            'empty_name' => ['', 'val', 'Flag name cannot be empty.'],
            'empty_value' => ['name', '', 'Flag value cannot be empty.'],
        ];
    }

    public function testGetters(): void
    {
        $flag = new FeatureFlag('flag-1', 'value-1');
        $this->assertEquals('flag-1', $flag->getName());
        $this->assertEquals('value-1', $flag->getValue());
    }

    public function testFromArray(): void
    {
        $flag = FeatureFlag::fromArray(['name' => 'flag-1', 'value' => 'value-1']);

        $this->assertEquals('flag-1', $flag->getName());
        $this->assertEquals('value-1', $flag->getValue());
    }
}
