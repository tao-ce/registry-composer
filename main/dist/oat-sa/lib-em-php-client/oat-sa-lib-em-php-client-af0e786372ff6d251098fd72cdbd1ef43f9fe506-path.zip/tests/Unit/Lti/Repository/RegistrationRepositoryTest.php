<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022-2024 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Lti\Repository;

use BadMethodCallException;
use OAT\Library\EnvironmentManagementClient\Converter\LtiRegistrationConverter;
use OAT\Library\EnvironmentManagementClient\Lti\Repository\RegistrationRepository;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationCollection;
use OAT\Library\EnvironmentManagementClient\Repository\LtiRegistrationRepositoryInterface;
use OAT\Library\Lti1p3Core\Registration\RegistrationInterface;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;

class RegistrationRepositoryTest extends TestCase
{
    private RegistrationRepository $subject;
    private LtiRegistrationRepositoryInterface|MockObject $ltiRegistrationRepositoryMock;
    private LtiRegistrationConverter|MockObject $ltiRegistrationConverterMock;

    protected function setUp(): void
    {
        $this->ltiRegistrationRepositoryMock = $this->createMock(LtiRegistrationRepositoryInterface::class);
        $this->ltiRegistrationConverterMock = $this->createMock(LtiRegistrationConverter::class);

        $this->subject = new RegistrationRepository(
            $this->ltiRegistrationRepositoryMock,
            $this->ltiRegistrationConverterMock
        );
    }

    public function testFind(): void
    {
        $ltiRegistrationMock = $this->createMock(LtiRegistration::class);
        $registrationMock = $this->createMock(RegistrationInterface::class);

        $this->ltiRegistrationRepositoryMock
            ->expects($this->once())
            ->method('find')
            ->with('identifier')
            ->willReturn($ltiRegistrationMock);

        $this->ltiRegistrationConverterMock
            ->expects($this->once())
            ->method('convert')
            ->with($ltiRegistrationMock)
            ->willReturn($registrationMock);

        $this->assertSame(
            $registrationMock,
            $this->subject->find('identifier'),
        );
    }

    public function testFindAll(): void
    {
        $ltiRegistrationMock = $this->createMock(LtiRegistration::class);
        $ltiRegistrationCollectionMock = $this->createMock(LtiRegistrationCollection::class);
        $registrationMock = $this->createMock(RegistrationInterface::class);

        $this->ltiRegistrationRepositoryMock
            ->expects($this->once())
            ->method('findAll')
            ->willReturn($ltiRegistrationCollectionMock);

        $ltiRegistrationCollectionMock
            ->expects($this->once())
            ->method('all')
            ->willReturn([$ltiRegistrationMock]);

        $this->ltiRegistrationConverterMock
            ->expects($this->once())
            ->method('convert')
            ->with($ltiRegistrationMock)
            ->willReturn($registrationMock);

        $this->assertSame(
            [$registrationMock],
            $this->subject->findAll()
        );
    }

    public function testFindByClientId(): void
    {
        $ltiRegistrationMock = $this->createMock(LtiRegistration::class);
        $ltiRegistrationCollection = new LtiRegistrationCollection();
        $registrationMock = $this->createMock(RegistrationInterface::class);

        $ltiRegistrationCollection->add($ltiRegistrationMock);

        $this->ltiRegistrationRepositoryMock
            ->expects($this->once())
            ->method('findAll')
            ->with('clientId')
            ->willReturn($ltiRegistrationCollection);

        $this->ltiRegistrationConverterMock
            ->expects($this->once())
            ->method('convert')
            ->with($ltiRegistrationMock)
            ->willReturn($registrationMock);

        $this->assertSame(
            $registrationMock,
            $this->subject->findByClientId('clientId')
        );
    }

    public function testFindByPlatformIssuer(): void
    {
        $ltiRegistrationMock = $this->createMock(LtiRegistration::class);
        $ltiRegistrationCollection = new LtiRegistrationCollection();
        $registrationMock = $this->createMock(RegistrationInterface::class);

        $ltiRegistrationCollection->add($ltiRegistrationMock);

        $this->ltiRegistrationRepositoryMock
            ->expects($this->once())
            ->method('findAll')
            ->with('clientId', 'platformIssuer')
            ->willReturn($ltiRegistrationCollection);

        $this->ltiRegistrationConverterMock
            ->expects($this->once())
            ->method('convert')
            ->with($ltiRegistrationMock)
            ->willReturn($registrationMock);

        $this->assertSame(
            $registrationMock,
            $this->subject->findByPlatformIssuer('platformIssuer', 'clientId')
        );
    }

    public function testFindByToolIssuer(): void
    {
        $this->expectException(BadMethodCallException::class);
        $this->expectExceptionMessage('Not implemented');
        $this->subject->findByToolIssuer('toolIssuer', 'clientId');
    }
}
