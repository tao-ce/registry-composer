<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Converter;

use OAT\Library\EnvironmentManagementClient\Converter\LtiPlatformConverter;
use OAT\Library\EnvironmentManagementClient\Model\LtiPlatform;
use OAT\Library\Lti1p3Core\Platform\PlatformInterface;
use PHPUnit\Framework\TestCase;

class LtiPlatformConverterTest extends TestCase
{
    private LtiPlatformConverter $subject;

    protected function setUp(): void
    {
        $this->subject = new LtiPlatformConverter();
    }

    public function testConvert(): void
    {
        $platform = new LtiPlatform(
            'platform-id',
            'platform-name',
            'platform-audience',
            'platform-oidc-authentication-url',
            'platform-oauth2-access-token-url'
        );

        $convertedLtiPlatform = $this->subject->convert($platform);

        $this->assertInstanceOf(PlatformInterface::class, $convertedLtiPlatform);
        $this->assertSame('platform-id', $convertedLtiPlatform->getIdentifier());
        $this->assertSame('platform-name', $convertedLtiPlatform->getName());
        $this->assertSame('platform-audience', $convertedLtiPlatform->getAudience());
        $this->assertSame('platform-oidc-authentication-url', $convertedLtiPlatform->getOidcAuthenticationUrl());
        $this->assertSame('platform-oauth2-access-token-url', $convertedLtiPlatform->getOAuth2AccessTokenUrl());
    }
}
