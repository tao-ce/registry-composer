<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2022 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Converter;

use OAT\Library\EnvironmentManagementClient\Converter\LtiToolConverter;
use OAT\Library\EnvironmentManagementClient\Model\LtiTool;
use OAT\Library\Lti1p3Core\Tool\ToolInterface;
use PHPUnit\Framework\TestCase;

class LtiToolConverterTest extends TestCase
{
    private LtiToolConverter $subject;

    protected function setUp(): void
    {
        $this->subject = new LtiToolConverter();
    }

    public function testConvert(): void
    {
        $tool = new LtiTool(
            'tool-id',
            'tool-name',
            'tool-audience',
            'tool-oidc-initiation-url',
            'tool-launch-url',
            'tool-deep-linking-url',
        );

        $convertedLtiTool = $this->subject->convert($tool);

        $this->assertInstanceOf(ToolInterface::class, $convertedLtiTool);
        $this->assertSame('tool-id', $convertedLtiTool->getIdentifier());
        $this->assertSame('tool-name', $convertedLtiTool->getName());
        $this->assertSame('tool-audience', $convertedLtiTool->getAudience());
        $this->assertSame('tool-oidc-initiation-url', $convertedLtiTool->getOidcInitiationUrl());
        $this->assertSame('tool-launch-url', $convertedLtiTool->getLaunchUrl());
        $this->assertSame('tool-deep-linking-url', $convertedLtiTool->getDeepLinkingUrl());
    }
}
