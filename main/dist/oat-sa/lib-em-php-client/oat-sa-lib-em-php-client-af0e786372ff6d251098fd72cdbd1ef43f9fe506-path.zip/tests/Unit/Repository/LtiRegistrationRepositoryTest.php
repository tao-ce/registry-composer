<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Repository;

use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\LtiRegistrationNotFoundException;
use OAT\Library\EnvironmentManagementClient\Model\Configuration;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlag;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistration;
use OAT\Library\EnvironmentManagementClient\Model\LtiRegistrationCollection;
use OAT\Library\EnvironmentManagementClient\Repository\ConfigurationRepository;
use OAT\Library\EnvironmentManagementClient\Repository\FeatureFlagRepository;
use OAT\Library\EnvironmentManagementClient\Repository\LtiRegistrationRepository;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\ResponseInterface;

class LtiRegistrationRepositoryTest extends TestCase
{
    private LtiRegistrationRepository $subject;
    private HttpClientInterface|MockObject $httpClientMock;
    private CacheInterface|MockObject $cacheMock;
    private string $authServerGrpcGatewayHost = 'http://localhost:8080';

    protected function setUp(): void
    {
        $this->httpClientMock = $this->createMock(HttpClientInterface::class);
        $this->cacheMock = $this->createMock(CacheInterface::class);

        $this->subject = new LtiRegistrationRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
        );
    }

    public function testFind(): void
    {
        $ltiRegistrationIdentifier = 'lti-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $ltiRegistrationIdentifier) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATION_CACHE_PREFIX, $ltiRegistrationIdentifier),
                    $key,
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode([
                'id' => 'lti-1',
                'clientId' => 'client-1',
                'platformId' => 'platform-1',
                'toolId' => 'tool-1',
                'deploymentIds' => ['deployment-1'],
                'platformKeyChain' => [
                    'id' => 'platform-key-chain-1',
                    'keySetName' => 'key-set-name-1',
                    'publicKey' => 'public-key-1',
                    'privateKey' => 'private-key-1',
                    'privateKeyPassphrase' => 'private-key-passphrase-1',
                ],
                'toolKeyChain' => [
                    'id' => 'tool-key-chain-1',
                    'keySetName' => 'key-set-name-1',
                    'publicKey' => 'public-key-1',
                    'privateKey' => 'private-key-1',
                    'privateKeyPassphrase' => 'private-key-passphrase-1',
                ],
            ]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations/%s',
                    $this->authServerGrpcGatewayHost,
                    $ltiRegistrationIdentifier,
                )
            )
            ->willReturn($responseMock);

        $ltiRegistration = $this->subject->find($ltiRegistrationIdentifier);

        $this->assertInstanceOf(LtiRegistration::class, $ltiRegistration);
        $this->assertSame('lti-1', $ltiRegistration->getId());
        $this->assertSame('client-1', $ltiRegistration->getClientId());
        $this->assertSame('platform-1', $ltiRegistration->getPlatformId());
        $this->assertSame('tool-1', $ltiRegistration->getToolId());
        $this->assertSame(['deployment-1'], $ltiRegistration->getDeploymentIds());
        $this->assertSame('platform-key-chain-1', $ltiRegistration->getPlatformKeyChain()->getId());
        $this->assertSame('key-set-name-1', $ltiRegistration->getPlatformKeyChain()->getKeySetName());
        $this->assertSame('public-key-1', $ltiRegistration->getPlatformKeyChain()->getPublicKey());
        $this->assertSame('private-key-1', $ltiRegistration->getPlatformKeyChain()->getPrivateKey());
        $this->assertSame('private-key-passphrase-1', $ltiRegistration->getPlatformKeyChain()->getPrivateKeyPassphrase());
        $this->assertSame('tool-key-chain-1', $ltiRegistration->getToolKeyChain()->getId());
        $this->assertSame('key-set-name-1', $ltiRegistration->getToolKeyChain()->getKeySetName());
        $this->assertSame('public-key-1', $ltiRegistration->getToolKeyChain()->getPublicKey());
        $this->assertSame('private-key-1', $ltiRegistration->getToolKeyChain()->getPrivateKey());
        $this->assertSame('private-key-passphrase-1', $ltiRegistration->getToolKeyChain()->getPrivateKeyPassphrase());
    }

    public function testFindWithNonDefaultCacheTtl(): void
    {
        $this->subject = new LtiRegistrationRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
            3600,
        );

        $ltiRegistrationIdentifier = 'lti-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(3600);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $ltiRegistrationIdentifier) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATION_CACHE_PREFIX, $ltiRegistrationIdentifier),
                    $key,
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode([
                'id' => 'lti-1',
                'clientId' => 'client-1',
                'platformId' => 'platform-1',
                'toolId' => 'tool-1',
                'deploymentIds' => ['deployment-1'],
                'platformKeyChain' => [
                    'id' => 'platform-key-chain-1',
                    'keySetName' => 'key-set-name-1',
                    'publicKey' => 'public-key-1',
                    'privateKey' => 'private-key-1',
                    'privateKeyPassphrase' => 'private-key-passphrase-1',
                ],
                'toolKeyChain' => [
                    'id' => 'tool-key-chain-1',
                    'keySetName' => 'key-set-name-1',
                    'publicKey' => 'public-key-1',
                    'privateKey' => 'private-key-1',
                    'privateKeyPassphrase' => 'private-key-passphrase-1',
                ],
            ]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations/%s',
                    $this->authServerGrpcGatewayHost,
                    $ltiRegistrationIdentifier,
                )
            )
            ->willReturn($responseMock);

        $ltiRegistration = $this->subject->find($ltiRegistrationIdentifier);

        $this->assertInstanceOf(LtiRegistration::class, $ltiRegistration);
        $this->assertSame('lti-1', $ltiRegistration->getId());
        $this->assertSame('client-1', $ltiRegistration->getClientId());
        $this->assertSame('platform-1', $ltiRegistration->getPlatformId());
        $this->assertSame('tool-1', $ltiRegistration->getToolId());
        $this->assertSame(['deployment-1'], $ltiRegistration->getDeploymentIds());
        $this->assertSame('platform-key-chain-1', $ltiRegistration->getPlatformKeyChain()->getId());
        $this->assertSame('key-set-name-1', $ltiRegistration->getPlatformKeyChain()->getKeySetName());
        $this->assertSame('public-key-1', $ltiRegistration->getPlatformKeyChain()->getPublicKey());
        $this->assertSame('private-key-1', $ltiRegistration->getPlatformKeyChain()->getPrivateKey());
        $this->assertSame('private-key-passphrase-1', $ltiRegistration->getPlatformKeyChain()->getPrivateKeyPassphrase());
        $this->assertSame('tool-key-chain-1', $ltiRegistration->getToolKeyChain()->getId());
        $this->assertSame('key-set-name-1', $ltiRegistration->getToolKeyChain()->getKeySetName());
        $this->assertSame('public-key-1', $ltiRegistration->getToolKeyChain()->getPublicKey());
        $this->assertSame('private-key-1', $ltiRegistration->getToolKeyChain()->getPrivateKey());
        $this->assertSame('private-key-passphrase-1', $ltiRegistration->getToolKeyChain()->getPrivateKeyPassphrase());
    }

    /**
     * @dataProvider clientIdPlatformIssuerProvider
     */
    public function testFindAll(string $clientId, string $platformIssuer, string $platformIssuerInCacheKey): void
    {
        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $clientId, $platformIssuer, $platformIssuerInCacheKey) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATIONS_CACHE_PREFIX, $clientId, $platformIssuerInCacheKey),
                    $key,
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode([
                'data' => [
                    [
                        'id' => 'lti-1',
                        'clientId' => 'client-1',
                        'platformId' => 'platform-1',
                        'toolId' => 'tool-1',
                        'deploymentIds' => ['deployment-1'],
                        'platformKeyChain' => [
                            'id' => 'platform-key-chain-1',
                            'keySetName' => 'key-set-name-1',
                            'publicKey' => 'public-key-1',
                            'privateKey' => 'private-key-1',
                            'privateKeyPassphrase' => 'private-key-passphrase-1',
                        ],
                        'toolKeyChain' => [
                            'id' => 'tool-key-chain-1',
                            'keySetName' => 'key-set-name-1',
                            'publicKey' => 'public-key-1',
                            'privateKey' => 'private-key-1',
                            'privateKeyPassphrase' => 'private-key-passphrase-1',
                        ],
                    ],
                    [
                        'id' => 'lti-2',
                        'clientId' => 'client-2',
                        'platformId' => 'platform-2',
                        'toolId' => 'tool-2',
                        'deploymentIds' => ['deployment-2'],
                        'platformKeyChain' => [
                            'id' => 'platform-key-chain-2',
                            'keySetName' => 'key-set-name-2',
                            'publicKey' => 'public-key-2',
                            'privateKey' => 'private-key-2',
                            'privateKeyPassphrase' => 'private-key-passphrase-2',
                        ],
                        'toolKeyChain' => [
                            'id' => 'tool-key-chain-2',
                            'keySetName' => 'key-set-name-2',
                            'publicKey' => 'public-key-2',
                            'privateKey' => 'private-key-2',
                            'privateKeyPassphrase' => 'private-key-passphrase-2',
                        ],
                    ],
                ],
            ]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations',
                    $this->authServerGrpcGatewayHost,
                )
            )
            ->willReturn($responseMock);

        $ltiRegistrations = $this->subject->findAll($clientId, $platformIssuer);

        $this->assertInstanceOf(LtiRegistrationCollection::class, $ltiRegistrations);
        $this->assertCount(2, $ltiRegistrations);
        $this->assertSame('lti-1', $ltiRegistrations->get('lti-1')->getId());
        $this->assertSame('lti-2', $ltiRegistrations->get('lti-2')->getId());
    }

    public function testFindAllWithNon200StatusCode(): void
    {
        $clientId = 'clientId';
        $platformIssuer = 'platformIssuer';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $clientId, $platformIssuer) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATIONS_CACHE_PREFIX, $clientId, $platformIssuer),
                    $key,
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->exactly(2))
            ->method('getStatusCode')
            ->willReturn(404);
        $responseMock
            ->expects($this->never())
            ->method('getContent');

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations',
                    $this->authServerGrpcGatewayHost,
                )
            )
            ->willReturn($responseMock);

        $this->expectException(LtiRegistrationNotFoundException::class);
        $this->expectExceptionMessage('LTI registrations with clientId clientId and platformIssuer platformIssuer not found. Non-200 status code received: 404');

        $this->subject->findAll($clientId, $platformIssuer);

    }

    public function testFindAllWithInvalidResponse(): void
    {
        $clientId = 'clientId';
        $platformIssuer = 'platformIssuer';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $clientId, $platformIssuer) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATIONS_CACHE_PREFIX, $clientId, $platformIssuer),
                    $key,
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode([]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations',
                    $this->authServerGrpcGatewayHost,
                )
            )
            ->willReturn($responseMock);

        $this->expectException(LtiRegistrationNotFoundException::class);
        $this->expectExceptionMessage('LTI registrations with clientId clientId and platformIssuer platformIssuer not found. No data key in response.');

        $this->subject->findAll($clientId, $platformIssuer);
    }

    public function testFindAllWithUnexpectedError(): void
    {
        $clientId = 'clientId';
        $platformIssuer = 'platformIssuer';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $clientId, $platformIssuer) {
                $this->assertEquals(
                    sprintf(LtiRegistrationRepository::LTI_REGISTRATIONS_CACHE_PREFIX, $clientId, $platformIssuer),
                    $key,
                );

                return $callback($itemMock);
            });

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/lti-registrations',
                    $this->authServerGrpcGatewayHost,
                )
            )
            ->willThrowException(new \Exception('reason'));

        $this->expectException(EnvironmentManagementClientException::class);
        $this->expectExceptionMessage('Failed to fetch LTI registrations with clientId clientId and platformIssuer platformIssuer: reason');

        $this->subject->findAll($clientId, $platformIssuer);
    }

    public function clientIdPlatformIssuerProvider(): array
    {
        return [
            ['client-id', 'platform-issuer', 'platformissuer'],
            ['client-id', 'platform-issuer-with-special-chars!%^!@', 'platformissuerwithspecialchars'],
            ['', 'platform-issuer', 'platformissuer'],
            ['client-id', '', ''],
            ['', '', ''],
        ];
    }
}
