<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2025 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Repository;

use Exception;
use OAT\Library\EnvironmentManagementClient\Exception\ConfigurationNotFoundException;
use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Model\Configuration;
use OAT\Library\EnvironmentManagementClient\Repository\ConfigurationRepository;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\ResponseInterface;

class ConfigurationRepositoryTest extends TestCase
{
    private ConfigurationRepository $subject;
    private HttpClientInterface|MockObject $httpClientMock;
    private CacheInterface|MockObject $cacheMock;
    private string $authServerGrpcGatewayHost = 'http://localhost:8080';

    protected function setUp(): void
    {
        $this->httpClientMock = $this->createMock(HttpClientInterface::class);
        $this->cacheMock = $this->createMock(CacheInterface::class);

        $this->subject = new ConfigurationRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
        );
    }

    public function testFind(): void
    {
        $tenantId = 'tenant-1';
        $configName = 'config-1';
        $configValue = 'value-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $tenantId, $configName) {
                $this->assertEquals(
                    sprintf(ConfigurationRepository::CONFIGURATION_CACHE_PREFIX, $tenantId, $configName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode(['name' => $configName, 'value' => $configValue]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/configurations/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $configName,
                )
            )
            ->willReturn($responseMock);

        $configuration = $this->subject->find($tenantId, $configName);

        $this->assertInstanceOf(Configuration::class, $configuration);
        $this->assertEquals($configName, $configuration->getName());
        $this->assertEquals($configValue, $configuration->getStringValue());
    }

    public function testFindWithNonDefaultCacheTtl(): void
    {
        $this->subject = new ConfigurationRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
            3600,
        );

        $tenantId = 'tenant-1';
        $configName = 'config-1';
        $configValue = 'value-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(3600);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $tenantId, $configName) {
                $this->assertEquals(
                    sprintf(ConfigurationRepository::CONFIGURATION_CACHE_PREFIX, $tenantId, $configName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode(['name' => $configName, 'value' => $configValue]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/configurations/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $configName,
                )
            )
            ->willReturn($responseMock);

        $configuration = $this->subject->find($tenantId, $configName);

        $this->assertInstanceOf(Configuration::class, $configuration);
        $this->assertEquals($configName, $configuration->getName());
        $this->assertEquals($configValue, $configuration->getStringValue());
    }

    public function testFindIfResponseIsNon200(): void
    {
        $tenantId = 'tenant-1';
        $configName = 'config-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($tenantId, $itemMock, $configName) {
                $this->assertEquals(
                    sprintf(ConfigurationRepository::CONFIGURATION_CACHE_PREFIX, $tenantId, $configName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->exactly(2))
            ->method('getStatusCode')
            ->willReturn(404);
        $responseMock
            ->expects($this->never())
            ->method('getContent');

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/configurations/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $configName,
                )
            )
            ->willReturn($responseMock);

        $this->expectException(ConfigurationNotFoundException::class);
        $this->expectExceptionMessage('Configuration with id config-1 not found. Non-200 status code returned: 404');

        $this->subject->find($tenantId, $configName);
    }

    public function testFindEmpty(): void
    {
        $tenantId = 'tenant-1';
        $configName = 'config-1';
        $configValue = '';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $tenantId, $configName) {
                $this->assertEquals(
                    sprintf(ConfigurationRepository::CONFIGURATION_CACHE_PREFIX, $tenantId, $configName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode(['name' => $configName, 'value' => $configValue]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/configurations/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $configName,
                )
            )
            ->willReturn($responseMock);

        $this->expectException(ConfigurationNotFoundException::class);
        $this->expectExceptionMessage('Configuration with id config-1 is empty.');

        $this->subject->find($tenantId, $configName);
    }

    public function testFindWithUnexpectedError(): void
    {
        $tenantId = 'tenant-1';
        $configName = 'config-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($tenantId, $itemMock, $configName) {
                $this->assertEquals(
                    sprintf(ConfigurationRepository::CONFIGURATION_CACHE_PREFIX, $tenantId, $configName),
                    $key
                );

                return $callback($itemMock);
            });

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/configurations/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $configName,
                )
            )
            ->willThrowException(new Exception('reason'));

        $this->expectException(EnvironmentManagementClientException::class);
        $this->expectExceptionMessage('Failed to fetch configuration with id config-1: reason');

        $this->subject->find($tenantId, $configName);
    }
}
