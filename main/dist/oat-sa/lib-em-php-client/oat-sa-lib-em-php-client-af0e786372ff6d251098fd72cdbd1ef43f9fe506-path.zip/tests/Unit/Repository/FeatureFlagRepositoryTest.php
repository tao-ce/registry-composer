<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Unit\Repository;

use OAT\Library\EnvironmentManagementClient\Exception\EnvironmentManagementClientException;
use OAT\Library\EnvironmentManagementClient\Exception\FeatureFlagNotFoundException;
use OAT\Library\EnvironmentManagementClient\Model\Configuration;
use OAT\Library\EnvironmentManagementClient\Model\FeatureFlag;
use OAT\Library\EnvironmentManagementClient\Repository\ConfigurationRepository;
use OAT\Library\EnvironmentManagementClient\Repository\FeatureFlagRepository;
use PHPUnit\Framework\MockObject\MockObject;
use PHPUnit\Framework\TestCase;
use Symfony\Contracts\Cache\CacheInterface;
use Symfony\Contracts\Cache\ItemInterface;
use Symfony\Contracts\HttpClient\HttpClientInterface;
use Symfony\Contracts\HttpClient\ResponseInterface;

class FeatureFlagRepositoryTest extends TestCase
{
    private FeatureFlagRepository $subject;
    private HttpClientInterface|MockObject $httpClientMock;
    private CacheInterface|MockObject $cacheMock;
    private string $authServerGrpcGatewayHost = 'http://localhost:8080';

    protected function setUp(): void
    {
        $this->httpClientMock = $this->createMock(HttpClientInterface::class);
        $this->cacheMock = $this->createMock(CacheInterface::class);

        $this->subject = new FeatureFlagRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
        );
    }

    public function testFind(): void
    {
        $tenantId = 'tenant-1';
        $featureFlagName = 'ff-1';
        $featureFlagValue = 'value-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $tenantId, $featureFlagName) {
                $this->assertEquals(
                    sprintf(FeatureFlagRepository::FEATURE_FLAG_CACHE_PREFIX, $tenantId, $featureFlagName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode(['name' => $featureFlagName, 'value' => $featureFlagValue]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/feature-flags/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $featureFlagName,
                )
            )
            ->willReturn($responseMock);

        $featureFlag = $this->subject->find($tenantId, $featureFlagName);

        $this->assertInstanceOf(FeatureFlag::class, $featureFlag);
        $this->assertEquals($featureFlagName, $featureFlag->getName());
        $this->assertEquals($featureFlagValue, $featureFlag->getValue());
    }

    public function testFindWithNonDefaultCacheTtl(): void
    {
        $this->subject = new FeatureFlagRepository(
            $this->httpClientMock,
            $this->cacheMock,
            $this->authServerGrpcGatewayHost,
            3600,
        );

        $tenantId = 'tenant-1';
        $featureFlagName = 'ff-1';
        $featureFlagValue = 'value-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(3600);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($itemMock, $tenantId, $featureFlagName) {
                $this->assertEquals(
                    sprintf(FeatureFlagRepository::FEATURE_FLAG_CACHE_PREFIX, $tenantId, $featureFlagName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->once())
            ->method('getStatusCode')
            ->willReturn(200);
        $responseMock
            ->expects($this->once())
            ->method('getContent')
            ->willReturn(json_encode(['name' => $featureFlagName, 'value' => $featureFlagValue]));

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/feature-flags/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $featureFlagName,
                )
            )
            ->willReturn($responseMock);

        $featureFlag = $this->subject->find($tenantId, $featureFlagName);

        $this->assertInstanceOf(FeatureFlag::class, $featureFlag);
        $this->assertEquals($featureFlagName, $featureFlag->getName());
        $this->assertEquals($featureFlagValue, $featureFlag->getValue());
    }

    public function testFindIfResponseIsNon200(): void
    {
        $tenantId = 'tenant-1';
        $featureFlagName = 'ff-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($tenantId, $itemMock, $featureFlagName) {
                $this->assertEquals(
                    sprintf(FeatureFlagRepository::FEATURE_FLAG_CACHE_PREFIX, $tenantId, $featureFlagName),
                    $key
                );

                return $callback($itemMock);
            });

        $responseMock = $this->createMock(ResponseInterface::class);
        $responseMock
            ->expects($this->exactly(2))
            ->method('getStatusCode')
            ->willReturn(404);
        $responseMock
            ->expects($this->never())
            ->method('getContent');

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/feature-flags/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $featureFlagName,
                )
            )
            ->willReturn($responseMock);

        $this->expectException(FeatureFlagNotFoundException::class);
        $this->expectExceptionMessage('Feature flag with id ff-1 not found. Non-200 status code received: 404');

        $this->subject->find($tenantId, $featureFlagName);
    }

    public function testFindWithUnexpectedError(): void
    {
        $tenantId = 'tenant-1';
        $featureFlagName = 'ff-1';

        $itemMock = $this->createMock(ItemInterface::class);
        $itemMock
            ->expects($this->once())
            ->method('expiresAfter')
            ->with(300);

        $this->cacheMock
            ->expects($this->once())
            ->method('get')
            ->willReturnCallback(function (string $key, callable $callback) use ($tenantId, $itemMock, $featureFlagName) {
                $this->assertEquals(
                    sprintf(FeatureFlagRepository::FEATURE_FLAG_CACHE_PREFIX, $tenantId, $featureFlagName),
                    $key
                );

                return $callback($itemMock);
            });

        $this->httpClientMock
            ->expects($this->once())
            ->method('request')
            ->with(
                'GET',
                sprintf(
                    '%s/api/v1/tenants/%s/feature-flags/%s',
                    $this->authServerGrpcGatewayHost,
                    $tenantId,
                    $featureFlagName,
                )
            )
            ->willThrowException(new \Exception('reason'));

        $this->expectException(EnvironmentManagementClientException::class);
        $this->expectExceptionMessage('Failed to fetch feature flag with id ff-1: reason');

        $this->subject->find($tenantId, $featureFlagName);
    }
}
