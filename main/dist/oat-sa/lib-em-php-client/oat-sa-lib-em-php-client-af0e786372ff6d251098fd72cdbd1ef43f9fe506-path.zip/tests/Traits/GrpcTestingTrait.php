<?php

// SPDX-FileCopyrightText: 2012-2026 Open Assessment Technologies S.A.
// Copyright (C) 2021 (original work) Open Assessment Technologies SA;
//
// SPDX-License-Identifier: AGPL-3.0-only OR LicenseRef-TAO-Commercial-License

declare(strict_types=1);

namespace OAT\Library\EnvironmentManagementClient\Tests\Traits;

use Grpc\UnaryCall;
use InvalidArgumentException;
use stdClass;

trait GrpcTestingTrait
{
    protected function createMockCall($response = null, int $statusCode = 0, string $statusDetails = ''): UnaryCall
    {
        $status = new stdClass();
        $status->code = $statusCode;
        $status->details = $statusDetails;

        $mockUnaryCall = $this->createMock(UnaryCall::class);
        $mockUnaryCall->expects($this->once())
            ->method('wait')
            ->willReturn([$response, $status]);

        return $mockUnaryCall;
    }

    protected function createMockCallWithException(): UnaryCall
    {
        $mockUnaryCall = $this->createMock(UnaryCall::class);
        $mockUnaryCall->expects($this->once())
            ->method('wait')
            ->willThrowException(new InvalidArgumentException());

        return $mockUnaryCall;
    }
}
